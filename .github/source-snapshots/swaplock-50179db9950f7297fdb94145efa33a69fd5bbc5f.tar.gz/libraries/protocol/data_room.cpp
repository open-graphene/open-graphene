/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <graphene/protocol/data_room.hpp>

#include <fc/io/raw.hpp>

namespace graphene { namespace protocol {

constexpr size_t DATA_ROOM_MAX_NAME_LENGTH = 256;

bool operator < ( const data_room_member_ref& a, const data_room_member_ref& b )
{
   if( a.which() != b.which() )
      return a.which() < b.which();
   if( a.is_type<account_id_type>() )
      return a.get<account_id_type>() < b.get<account_id_type>();
   if( a.is_type<public_key_type>() )
      return a.get<public_key_type>() < b.get<public_key_type>();
   return a.get<data_room_id_type>() < b.get<data_room_id_type>();
}

static void validate_data_room_name( const string& name )
{
   FC_ASSERT( !name.empty(), "Room name should not be empty" );
   FC_ASSERT( name.size() <= DATA_ROOM_MAX_NAME_LENGTH,
              "Room name should not be longer than ${max} bytes", ("max", DATA_ROOM_MAX_NAME_LENGTH) );
}

static void validate_data_room_permissions( uint32_t permissions )
{
   FC_ASSERT( (permissions & ~DATA_ROOM_PERM_ALL) == 0,
              "Unknown permission flags: ${p}", ("p", permissions) );
}

/// A key member can never be the caller of an operation, because fee_payer() always returns
/// an account. Reject permissions it could not possibly exercise, so the member record does
/// not advertise rights that silently do nothing.
static void validate_data_room_member_permissions( const data_room_member_ref& member,
                                                   uint32_t permissions )
{
   validate_data_room_permissions( permissions );

   // A room member is strictly a reader: it cannot sign, so it can exercise NOTHING -
   // not even the permissions a bare key can (a key at least authorizes as author).
   if( member.is_type<data_room_id_type>() )
   {
      FC_ASSERT( permissions == 0,
                 "A room member cannot hold any permission flags: a room cannot sign, "
                 "so access through a room is read-only" );
      return;
   }

   if( !member.is_type<public_key_type>() )
      return;

   const uint32_t unusable = permissions & ~DATA_ROOM_PERM_KEY_MEMBER_MASK;
   FC_ASSERT( unusable == 0,
              "A key member cannot hold permission flags ${p}: a bare public key cannot pay a "
              "fee and therefore cannot be the caller of any operation",
              ("p", unusable) );
}

void data_room_create_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   validate_data_room_name( name );
   if( room_key.valid() )
      FC_ASSERT( !room_key->empty(), "Room key should not be empty when present; omit it for a public room" );
}

void data_room_update_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   bool updating_something = false;

   if( new_name.valid() )
   {
      updating_something = true;
      validate_data_room_name( *new_name );
   }
   if( new_description.valid() )
      updating_something = true;
   if( new_subject.valid() )
      updating_something = true;
   if( new_owner.valid() )
      updating_something = true;

   FC_ASSERT( updating_something,
              "Should change something - at least one of the optional data fields should be present" );
}

void data_room_delete_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
}

void data_room_member_add_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   validate_data_room_member_permissions( member, permissions );
   for( const auto& epoch_key : epoch_keys )
      FC_ASSERT( !epoch_key.second.empty(),
                 "Historical epoch key for epoch ${e} should not be empty", ("e", epoch_key.first) );
}

share_type data_room_member_add_operation::calculate_fee( const fee_params_t& schedule )const
{
   share_type core_fee_required = schedule.fee;
   core_fee_required += calculate_data_fee( fc::raw::pack_size(*this), schedule.price_per_kbyte );
   return core_fee_required;
}

void data_room_member_update_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   validate_data_room_member_permissions( member, permissions );
}

void data_room_member_remove_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
}

void data_room_rotate_key_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   FC_ASSERT( !member_keys.empty(), "Member keys should not be empty" );
   for( const auto& member_key : member_keys )
      FC_ASSERT( !member_key.second.empty(),
                 "Member key for member ${m} should not be empty", ("m", member_key.first) );
}

share_type data_room_rotate_key_operation::calculate_fee( const fee_params_t& schedule )const
{
   share_type core_fee_required = schedule.fee;
   core_fee_required += calculate_data_fee( fc::raw::pack_size(*this), schedule.price_per_kbyte );
   return core_fee_required;
}

} } // graphene::protocol

GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_create_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_update_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_delete_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_add_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_update_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_remove_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_rotate_key_operation::fee_params_t )

GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_create_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_update_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_delete_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_add_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_update_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_remove_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_rotate_key_operation )
