/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once
#include <graphene/protocol/base.hpp>
#include <graphene/protocol/asset.hpp>

namespace graphene { namespace protocol {

   /// The entity a data room is attached to: nothing, a tokenized asset, or an account.
   /// Extensible - new subject types may be appended in future protocol upgrades.
   using data_room_subject = fc::static_variant< void_t, asset_id_type, account_id_type >;

   /**
    * @brief A data room member: an account, a bare public key, or ANOTHER data room.
    *
    * A key member has no account behind it and therefore cannot pay a fee, which means it
    * can never be the @c caller of any operation - fee_payer() always returns an account.
    * Key members exist so that ephemeral processes can be granted room access without
    * creating accounts, which in Graphene are permanent and occupy a global namespace.
    *
    * A ROOM member is the keyring: the grantor room's key wrapped with the grantee room's
    * key, so whoever can open the grantee room can read the grantor. Access composes -
    * a room that can be opened opens everything IT can open - and that transitivity is
    * cryptographic fact, not policy. A room cannot sign anything, so a room member is
    * strictly a READER: it holds no permission flags and can never author or call.
    * Rotation semantics are the ordinary member semantics: the envelope wraps specific
    * epochs, rotating the grantor cuts the keyring off from future epochs until someone
    * holding BOTH keys re-grants (remove + add with epoch keys, one transaction).
    *
    * The chain performs no cryptography on member keys: the room key is carried as an
    * opaque, client-encrypted string, so a key or room member is never validated against
    * anything cryptographic.
    */
   using data_room_member_ref = fc::static_variant< account_id_type, public_key_type,
                                                    data_room_id_type >;

   /// Ordering for @ref data_room_member_ref: by variant tag first, then by value.
   /// Declared here (not as a template) so it applies to this instantiation only and is
   /// found by ADL for std::less, which flat_map / flat_set / multi_index rely on.
   /// @note fc::static_variant::type_lt orders by which() alone and would collapse all
   ///       key members into a single equivalence class - it must not be used here.
   bool operator < ( const data_room_member_ref& a, const data_room_member_ref& b );

   /// Permission flags for data room members. The room owner implicitly has all permissions.
   constexpr uint32_t DATA_ROOM_PERM_UPDATE_ROOM        = 0x0001; ///< Update room name / description
   constexpr uint32_t DATA_ROOM_PERM_ADD_MEMBERS        = 0x0002; ///< Add new members
   constexpr uint32_t DATA_ROOM_PERM_REMOVE_MEMBERS     = 0x0004; ///< Remove members
   constexpr uint32_t DATA_ROOM_PERM_MANAGE_PERMISSIONS = 0x0008; ///< Change members' permission flags
   constexpr uint32_t DATA_ROOM_PERM_CREATE_CONTENT     = 0x0010; ///< Create content cards in the room
   constexpr uint32_t DATA_ROOM_PERM_MANAGE_CONTENT     = 0x0020; ///< Update / remove other members' content cards
   constexpr uint32_t DATA_ROOM_PERM_ROTATE_KEYS        = 0x0040; ///< Rotate the room encryption key
   constexpr uint32_t DATA_ROOM_PERM_GRANT_CONTENT      = 0x0080; ///< Grant single cards to outsiders
   constexpr uint32_t DATA_ROOM_PERM_ALL                = 0x00FF;

   /**
    * Permissions a key member may hold.
    *
    * A permission is usable by a bare key only if the operation exercising it names its
    * subject in a field separate from the fee payer - fee_payer() always returns an account,
    * so a key can never be the payer. The content card operations do this; the data room
    * management operations keep @c caller as an account, so their permissions stay
    * unreachable for a key and are rejected rather than silently stored.
    */
   constexpr uint32_t DATA_ROOM_PERM_KEY_MEMBER_MASK    = DATA_ROOM_PERM_CREATE_CONTENT
                                                        | DATA_ROOM_PERM_MANAGE_CONTENT;

   /**
    * @brief Create a new data room
    * @ingroup operations
    *
    * A data room is a container for content cards (documents) that can be attached to a
    * tokenized asset or an account. Attaching a room to an asset requires the room owner
    * to be the asset's issuer at creation time; the room does not follow later issuer
    * transfers - the room owner stays authoritative.
    *
    * If @ref room_key is absent the room is public and the key-epoch machinery is dormant.
    * Encryption can be bootstrapped later with @ref data_room_rotate_key_operation.
    */
   struct data_room_create_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee = 20 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset             fee;         ///< Operation fee
      account_id_type   owner;       ///< Owner of the data room
      string            name;        ///< Room name, unique per owner
      string            description; ///< Free-form description
      data_room_subject subject;     ///< What the room is attached to (nothing / asset / account)
      optional<string>  room_key;    ///< Encrypted room key; absent = public room

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return owner; }
      void            validate()const override;
   };

   /**
    * @brief Update a data room
    * @ingroup operations
    *
    * Name and description may be changed by the owner or a member with
    * DATA_ROOM_PERM_UPDATE_ROOM. Changing the subject or transferring ownership
    * is restricted to the owner.
    */
   struct data_room_update_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee = 5 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                       fee;             ///< Operation fee
      account_id_type             caller;          ///< The account updating the room
      data_room_id_type           room;            ///< ID of the data room
      optional<string>            new_name;        ///< New room name, optional
      optional<string>            new_description; ///< New description, optional
      optional<data_room_subject> new_subject;     ///< New subject, optional; owner only
      optional<account_id_type>   new_owner;       ///< Transfer ownership, optional; owner only

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return caller; }
      void            validate()const override;
   };

   /**
    * @brief Delete a data room
    * @ingroup operations
    *
    * Owner only. Cascade-removes all content cards, members and key epoch records.
    */
   struct data_room_delete_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee = 5 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset             fee;    ///< Operation fee
      account_id_type   caller; ///< The account deleting the room; must be the owner
      data_room_id_type room;   ///< ID of the data room

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return caller; }
      void            validate()const override;
   };

   /**
    * @brief Add a member to a data room
    * @ingroup operations
    *
    * Requires the caller to be the owner or a member with DATA_ROOM_PERM_ADD_MEMBERS.
    * For encrypted rooms @ref member_key must carry the room key encrypted to the new
    * member; @ref epoch_keys may carry keys for historical epochs (e.g. when re-adding
    * a former member).
    *
    * The new member may be a bare public key. A key member cannot be the caller of any
    * operation, so it may only hold permissions that are exercised through a field other
    * than @c caller - see DATA_ROOM_PERM_KEY_MEMBER_MASK.
    */
   struct data_room_member_add_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee             =  5 * GRAPHENE_BLOCKCHAIN_PRECISION;
         uint32_t price_per_kbyte = 10 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                fee;        ///< Operation fee
      account_id_type      caller;     ///< The account adding the member
      data_room_id_type    room;       ///< ID of the data room
      data_room_member_ref member;     ///< The account or public key to add as a member
      string               member_key; ///< Room key encrypted to the member; empty for public rooms
      /// Room keys for historical epochs, encrypted to the member; epoch -> key
      flat_map<uint32_t, string> epoch_keys;
      uint32_t          permissions = 0; ///< Permission flags, see DATA_ROOM_PERM_*

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return caller; }
      void            validate()const override;
      share_type      calculate_fee(const fee_params_t& k)const;
   };

   /**
    * @brief Update a data room member's permissions
    * @ingroup operations
    *
    * Requires the caller to be the owner or a member with DATA_ROOM_PERM_MANAGE_PERMISSIONS.
    * The owner's member record cannot be modified.
    */
   struct data_room_member_update_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee = 1 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                fee;      ///< Operation fee
      account_id_type      caller;   ///< The account updating the member
      data_room_id_type    room;     ///< ID of the data room
      data_room_member_ref member;   ///< The member to update
      uint32_t             permissions = 0; ///< New permission flags, see DATA_ROOM_PERM_*

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return caller; }
      void            validate()const override;
   };

   /**
    * @brief Remove a member from a data room
    * @ingroup operations
    *
    * Requires the caller to be the owner or a member with DATA_ROOM_PERM_REMOVE_MEMBERS.
    * The owner cannot be removed.
    *
    * The removed member's own key-epoch records are deleted along with the membership:
    * they are useless to anyone else, and retaining them would silently restore the
    * member's history on a future re-add. Remaining members keep their records, so
    * previously encrypted content stays decryptable for them. What the removed member
    * has already read is beyond any protocol's reach - re-adding them with history is
    * an explicit choice via data_room_member_add_operation::epoch_keys.
    */
   struct data_room_member_remove_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee = 1 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                fee;    ///< Operation fee
      account_id_type      caller; ///< The account removing the member
      data_room_id_type    room;   ///< ID of the data room
      data_room_member_ref member;  ///< The member to remove

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return caller; }
      void            validate()const override;
   };

   /**
    * @brief Rotate the encryption key of a data room
    * @ingroup operations
    *
    * Requires the caller to be the owner or a member with DATA_ROOM_PERM_ROTATE_KEYS.
    * Increments the room's key epoch and stores a new encrypted key for every member.
    * Also serves to bootstrap encryption on a previously public room.
    */
   struct data_room_rotate_key_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee             = 10 * GRAPHENE_BLOCKCHAIN_PRECISION;
         uint32_t price_per_kbyte = 10 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset             fee;    ///< Operation fee
      account_id_type   caller; ///< The account rotating the key
      data_room_id_type room;   ///< ID of the data room
      /// New room key encrypted to each member; must cover all members (the owner is a
      /// member, so their envelope rides here too), no strangers
      flat_map<data_room_member_ref, string> member_keys;

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return caller; }
      void            validate()const override;
      share_type      calculate_fee(const fee_params_t& k)const;
   };

} } // graphene::protocol

FC_REFLECT_TYPENAME( graphene::protocol::data_room_subject )
FC_REFLECT_TYPENAME( graphene::protocol::data_room_member_ref )

FC_REFLECT( graphene::protocol::data_room_create_operation::fee_params_t, (fee) )
FC_REFLECT( graphene::protocol::data_room_update_operation::fee_params_t, (fee) )
FC_REFLECT( graphene::protocol::data_room_delete_operation::fee_params_t, (fee) )
FC_REFLECT( graphene::protocol::data_room_member_add_operation::fee_params_t, (fee)(price_per_kbyte) )
FC_REFLECT( graphene::protocol::data_room_member_update_operation::fee_params_t, (fee) )
FC_REFLECT( graphene::protocol::data_room_member_remove_operation::fee_params_t, (fee) )
FC_REFLECT( graphene::protocol::data_room_rotate_key_operation::fee_params_t, (fee)(price_per_kbyte) )

FC_REFLECT( graphene::protocol::data_room_create_operation,
            (fee)
            (owner)
            (name)
            (description)
            (subject)
            (room_key)
            (extensions)
          )

FC_REFLECT( graphene::protocol::data_room_update_operation,
            (fee)
            (caller)
            (room)
            (new_name)
            (new_description)
            (new_subject)
            (new_owner)
            (extensions)
          )

FC_REFLECT( graphene::protocol::data_room_delete_operation,
            (fee)
            (caller)
            (room)
            (extensions)
          )

FC_REFLECT( graphene::protocol::data_room_member_add_operation,
            (fee)
            (caller)
            (room)
            (member)
            (member_key)
            (epoch_keys)
            (permissions)
            (extensions)
          )

FC_REFLECT( graphene::protocol::data_room_member_update_operation,
            (fee)
            (caller)
            (room)
            (member)
            (permissions)
            (extensions)
          )

FC_REFLECT( graphene::protocol::data_room_member_remove_operation,
            (fee)
            (caller)
            (room)
            (member)
            (extensions)
          )

FC_REFLECT( graphene::protocol::data_room_rotate_key_operation,
            (fee)
            (caller)
            (room)
            (member_keys)
            (extensions)
          )

GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_create_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_update_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_delete_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_add_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_update_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_remove_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_rotate_key_operation::fee_params_t )

GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_create_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_update_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_delete_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_add_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_update_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_member_remove_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::data_room_rotate_key_operation )
