/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once
#include <graphene/protocol/base.hpp>
#include <graphene/protocol/asset.hpp>
#include <graphene/protocol/authority.hpp> // get_required_authorities for key authors
#include <graphene/protocol/data_room.hpp> // data_room_member_ref

namespace graphene { namespace protocol {

   /**
    * @brief Create a content card in a data room
    * @ingroup operations
    *
    * A content card describes a document (or other content) stored off-chain, identified
    * by its hash. Cards always belong to a data room; the author must be the room owner
    * or a member with DATA_ROOM_PERM_CREATE_CONTENT.
    *
    * The hash is a pure integrity anchor - sha256 of the document's plaintext - and is
    * deliberately NOT unique: the same document may legitimately be filed twice, and the
    * card's own object id is its identity. Readers verify content against the hash after
    * decryption; the chain performs no cryptography on it.
    *
    * The fee payer and the author are separate. This is what lets a bare key author a card:
    * a key cannot pay a fee, so some account must, while the key's own signature establishes
    * authorship. The payer cannot write under someone else's authorship - a key author must
    * sign (@ref get_required_authorities), and an account author distinct from the payer must
    * approve with its active authority (@ref get_required_active_authorities).
    *
    * @see balance_claim_operation for the same shape: one account pays, a bare key authorizes.
    */
   struct content_card_create_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee             = 20 * GRAPHENE_BLOCKCHAIN_PRECISION;
         uint32_t price_per_kbyte = 10 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                fee;          ///< Operation fee
      account_id_type      payer;        ///< The account paying the fee
      data_room_member_ref author;       ///< The member creating the card: an account or a key
      data_room_id_type    room;         ///< The data room this card belongs to
      string               hash;         ///< Content hash (sha256 of the plaintext)
      string               url;          ///< Content location
      string               type;         ///< Content type / MIME type
      string               description;  ///< Free-form description
      string               content_key;  ///< Content encryption key material; empty for public content
      string               storage_data; ///< Storage metadata

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return payer; }
      void            validate()const override;
      share_type      calculate_fee(const fee_params_t& k)const;

      void get_required_authorities( vector<authority>& a )const override
      {
         if( author.is_type<public_key_type>() )
            a.push_back( authority( 1, author.get<public_key_type>(), 1 ) );
      }
      void get_required_active_authorities( flat_set<account_id_type>& a )const override
      {
         // The payer is added by the transaction machinery; an account author that is not the
         // payer must approve separately, or the payer could forge authorship
         if( author.is_type<account_id_type>() && author.get<account_id_type>() != payer )
            a.insert( author.get<account_id_type>() );
      }
   };

   /**
    * @brief Update a content card
    * @ingroup operations
    *
    * The caller must be the card's author, the room owner, or a member with
    * DATA_ROOM_PERM_MANAGE_CONTENT.
    */
   struct content_card_update_operation : public base_operation
   {
      struct ext {
         optional<string> expected_hash; ///< Atomic comparison against the current revision
      };

      struct fee_params_t {
         uint64_t fee             = 20 * GRAPHENE_BLOCKCHAIN_PRECISION;
         uint32_t price_per_kbyte = 10 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                 fee;              ///< Operation fee
      account_id_type       payer;            ///< The account paying the fee
      data_room_member_ref  caller;           ///< The member updating the card: an account or a key
      content_card_id_type  content_id;       ///< ID of the content card
      optional<string>      new_hash;         ///< New content hash, optional
      optional<string>      new_url;          ///< New content location, optional
      optional<string>      new_type;         ///< New content type, optional
      optional<string>      new_description;  ///< New description, optional
      optional<string>      new_content_key;  ///< New content key, optional; refreshes key_epoch
      optional<string>      new_storage_data; ///< New storage metadata, optional

      extension<ext> extensions;

      account_id_type fee_payer()const { return payer; }
      void            validate()const override;
      share_type      calculate_fee(const fee_params_t& k)const;

      void get_required_authorities( vector<authority>& a )const override
      {
         if( caller.is_type<public_key_type>() )
            a.push_back( authority( 1, caller.get<public_key_type>(), 1 ) );
      }
      void get_required_active_authorities( flat_set<account_id_type>& a )const override
      {
         if( caller.is_type<account_id_type>() && caller.get<account_id_type>() != payer )
            a.insert( caller.get<account_id_type>() );
      }
   };

   /**
    * @brief Remove a content card
    * @ingroup operations
    *
    * The caller must be the card's author, the room owner, or a member with
    * DATA_ROOM_PERM_MANAGE_CONTENT.
    */
   struct content_card_remove_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee = 1 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                fee;        ///< Operation fee
      account_id_type      payer;      ///< The account paying the fee
      data_room_member_ref caller;     ///< The member removing the card: an account or a key
      content_card_id_type content_id; ///< ID of the content card

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return payer; }
      void            validate()const override;

      void get_required_authorities( vector<authority>& a )const override
      {
         if( caller.is_type<public_key_type>() )
            a.push_back( authority( 1, caller.get<public_key_type>(), 1 ) );
      }
      void get_required_active_authorities( flat_set<account_id_type>& a )const override
      {
         if( caller.is_type<account_id_type>() && caller.get<account_id_type>() != payer )
            a.insert( caller.get<account_id_type>() );
      }
   };

   /**
    * @brief Grant one content card to a single recipient, outside room membership
    * @ingroup operations
    *
    * A grant is the accountable form of disclosure: the card's content key, encrypted to
    * the grantee, recorded on chain with who granted it and when. The grantee gains exactly
    * one document - not the room, not its member list, not its other cards.
    *
    * The granter must be the room owner or a member with DATA_ROOM_PERM_GRANT_CONTENT.
    * Anyone who can read a card can leak its plaintext out-of-band; this permission does
    * not pretend to prevent that. What it gates is the on-chain act, so that every grant
    * has an author and a record.
    *
    * The grantee may be an account or a bare public key, and may already be a room member
    * - a member whose epoch access predates an old card can be granted just that card
    * instead of the room's whole history.
    *
    * Grants deliberately survive key rotation: the content key of a card never changes,
    * so rotating the room key - which protects what the room shares NEXT - does not
    * revoke a disclosure that was already made explicitly.
    */
   struct content_card_grant_create_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee             =  5 * GRAPHENE_BLOCKCHAIN_PRECISION;
         uint32_t price_per_kbyte = 10 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                fee;        ///< Operation fee
      account_id_type      granter;    ///< The account granting access
      content_card_id_type content_id; ///< The card being granted
      data_room_member_ref grantee;    ///< The account or public key receiving access
      string               key;        ///< The card's content key encrypted to the grantee

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return granter; }
      void            validate()const override;
      share_type      calculate_fee(const fee_params_t& k)const;
   };

   /**
    * @brief Revoke a content card grant
    * @ingroup operations
    *
    * The caller must be the original granter, the room owner, or a member with
    * DATA_ROOM_PERM_GRANT_CONTENT. Revocation removes the on-chain record - the stated
    * intent - and with it the grantee's envelope. It cannot remove what the grantee has
    * already read; that limit is physics, not policy.
    */
   struct content_card_grant_revoke_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee = 1 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                      fee;      ///< Operation fee
      account_id_type            caller;   ///< The account revoking the grant
      content_card_grant_id_type grant_id; ///< The grant to revoke

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return caller; }
      void            validate()const override;
   };

   /**
    * @brief Embed one content card into another data room, by reference
    * @ingroup operations
    *
    * A link is how one card lives in many rooms at once: the card stays in its home
    * room (which keeps deciding who may edit it), and the link places a REFERENCE in
    * the target room together with the card's content key re-wrapped to that room's
    * key. Readers of the target room always see the card's latest revision - updating
    * the card once updates it everywhere it is linked.
    *
    * The caller must be a member of the card's home room (whoever may read the case
    * may put it on another table) and must hold DATA_ROOM_PERM_CREATE_CONTENT in the
    * target room. An encrypted card cannot be linked into a public room - there is no
    * room key to wrap its content key to.
    *
    * Links deliberately survive content updates: they reference the card's identity,
    * not its bytes. When the card's content key rotates, existing links keep wrapping
    * the OLD key - stale until refreshed with content_card_link_update. That is the
    * revocation lever: rotate the key, refresh only the links that should keep access.
    */
   struct content_card_link_create_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee             =  5 * GRAPHENE_BLOCKCHAIN_PRECISION;
         uint32_t price_per_kbyte = 10 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                fee;        ///< Operation fee
      account_id_type      payer;      ///< The account paying the fee
      data_room_member_ref caller;     ///< The member placing the link: an account or a key
      content_card_id_type content_id; ///< The card being linked
      data_room_id_type    room;       ///< The TARGET room the card is embedded into
      string               link_key;   ///< The card's content key wrapped to the target room's key; empty for public content

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return payer; }
      void            validate()const override;
      share_type      calculate_fee(const fee_params_t& k)const;

      void get_required_authorities( vector<authority>& a )const override
      {
         if( caller.is_type<public_key_type>() )
            a.push_back( authority( 1, caller.get<public_key_type>(), 1 ) );
      }
      void get_required_active_authorities( flat_set<account_id_type>& a )const override
      {
         if( caller.is_type<account_id_type>() && caller.get<account_id_type>() != payer )
            a.insert( caller.get<account_id_type>() );
      }
   };

   /**
    * @brief Refresh a link's wrapped key after a rotation
    * @ingroup operations
    *
    * Two clocks can outdate a link's envelope: the target room rotating its key, and
    * the card rotating its content key. This operation re-wraps; the chain restamps
    * which epochs the new envelope corresponds to. The caller must be the original
    * linker or a member of the card's home room.
    */
   struct content_card_link_update_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee             =  5 * GRAPHENE_BLOCKCHAIN_PRECISION;
         uint32_t price_per_kbyte = 10 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                     fee;          ///< Operation fee
      account_id_type           payer;        ///< The account paying the fee
      data_room_member_ref      caller;       ///< The member refreshing the link
      content_card_link_id_type link_id;      ///< The link being refreshed
      string                    new_link_key; ///< The card's content key re-wrapped to the target room's key

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return payer; }
      void            validate()const override;
      share_type      calculate_fee(const fee_params_t& k)const;

      void get_required_authorities( vector<authority>& a )const override
      {
         if( caller.is_type<public_key_type>() )
            a.push_back( authority( 1, caller.get<public_key_type>(), 1 ) );
      }
      void get_required_active_authorities( flat_set<account_id_type>& a )const override
      {
         if( caller.is_type<account_id_type>() && caller.get<account_id_type>() != payer )
            a.insert( caller.get<account_id_type>() );
      }
   };

   /**
    * @brief Remove a link - take the card off this room's table
    * @ingroup operations
    *
    * The card itself is untouched; only the reference goes. The caller must be the
    * original linker, a member of the card's home room with DATA_ROOM_PERM_MANAGE_CONTENT,
    * or a member of the TARGET room with DATA_ROOM_PERM_MANAGE_CONTENT - a room may
    * always clear its own table.
    */
   struct content_card_link_remove_operation : public base_operation
   {
      struct fee_params_t {
         uint64_t fee = 1 * GRAPHENE_BLOCKCHAIN_PRECISION;
      };

      asset                     fee;     ///< Operation fee
      account_id_type           payer;   ///< The account paying the fee
      data_room_member_ref      caller;  ///< The member removing the link
      content_card_link_id_type link_id; ///< The link to remove

      extensions_type extensions;  ///< Unused. Reserved for future use.

      account_id_type fee_payer()const { return payer; }
      void            validate()const override;

      void get_required_authorities( vector<authority>& a )const override
      {
         if( caller.is_type<public_key_type>() )
            a.push_back( authority( 1, caller.get<public_key_type>(), 1 ) );
      }
      void get_required_active_authorities( flat_set<account_id_type>& a )const override
      {
         if( caller.is_type<account_id_type>() && caller.get<account_id_type>() != payer )
            a.insert( caller.get<account_id_type>() );
      }
   };

} } // graphene::protocol

FC_REFLECT( graphene::protocol::content_card_create_operation::fee_params_t, (fee)(price_per_kbyte) )
FC_REFLECT( graphene::protocol::content_card_update_operation::fee_params_t, (fee)(price_per_kbyte) )
FC_REFLECT( graphene::protocol::content_card_remove_operation::fee_params_t, (fee) )
FC_REFLECT( graphene::protocol::content_card_grant_create_operation::fee_params_t, (fee)(price_per_kbyte) )
FC_REFLECT( graphene::protocol::content_card_grant_revoke_operation::fee_params_t, (fee) )
FC_REFLECT( graphene::protocol::content_card_link_create_operation::fee_params_t, (fee)(price_per_kbyte) )
FC_REFLECT( graphene::protocol::content_card_link_update_operation::fee_params_t, (fee)(price_per_kbyte) )
FC_REFLECT( graphene::protocol::content_card_link_remove_operation::fee_params_t, (fee) )

FC_REFLECT( graphene::protocol::content_card_create_operation,
            (fee)
            (payer)
            (author)
            (room)
            (hash)
            (url)
            (type)
            (description)
            (content_key)
            (storage_data)
            (extensions)
          )

FC_REFLECT( graphene::protocol::content_card_update_operation::ext, (expected_hash) )
FC_REFLECT_TYPENAME(graphene::protocol::extension<graphene::protocol::content_card_update_operation::ext>)
FC_REFLECT( graphene::protocol::content_card_update_operation,
            (fee)
            (payer)
            (caller)
            (content_id)
            (new_hash)
            (new_url)
            (new_type)
            (new_description)
            (new_content_key)
            (new_storage_data)
            (extensions)
          )

FC_REFLECT( graphene::protocol::content_card_remove_operation,
            (fee)
            (payer)
            (caller)
            (content_id)
            (extensions)
          )

FC_REFLECT( graphene::protocol::content_card_grant_create_operation,
            (fee)
            (granter)
            (content_id)
            (grantee)
            (key)
            (extensions)
          )

FC_REFLECT( graphene::protocol::content_card_grant_revoke_operation,
            (fee)
            (caller)
            (grant_id)
            (extensions)
          )

FC_REFLECT( graphene::protocol::content_card_link_create_operation,
            (fee)
            (payer)
            (caller)
            (content_id)
            (room)
            (link_key)
            (extensions)
          )

FC_REFLECT( graphene::protocol::content_card_link_update_operation,
            (fee)
            (payer)
            (caller)
            (link_id)
            (new_link_key)
            (extensions)
          )

FC_REFLECT( graphene::protocol::content_card_link_remove_operation,
            (fee)
            (payer)
            (caller)
            (link_id)
            (extensions)
          )

GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_create_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_update_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_remove_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_grant_create_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_grant_revoke_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_create_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_update_operation::fee_params_t )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_remove_operation::fee_params_t )

GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_create_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_update_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_remove_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_grant_create_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_grant_revoke_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_create_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_update_operation )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_remove_operation )
