/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <graphene/pg_indexer/pg_indexer_plugin.hpp>
#include <graphene/pg_indexer/pg_writer.hpp>

#include <graphene/chain/database.hpp>
#include <graphene/chain/exceptions.hpp>
#include <graphene/chain/hardfork.hpp>
#include <graphene/chain/impacted.hpp>
#include <graphene/chain/operation_history_object.hpp>
#include <graphene/protocol/block.hpp>

#include <fc/log/logger.hpp>
#include <fc/thread/thread.hpp>

#include <boost/signals2/connection.hpp>

#include <deque>
#include <memory>

namespace graphene { namespace pg_indexer {

namespace detail {

struct get_fee_payer_visitor
{
   using result_type = account_id_type;
   template<typename operation_type>
   account_id_type operator()( const operation_type& op )const
   {
      return op.fee_payer();
   }
};

class pg_indexer_plugin_impl
{
   public:
      explicit pg_indexer_plugin_impl( pg_indexer_plugin& plugin )
         : _plugin( plugin ) {}

      void on_applied_block( const signed_block& b );
      void on_objects_delta( char kind, const std::vector<object_id_type>& ids );
      void flush_open_bundle();
      void enqueue_reconcile_bundle();
      bool is_excluded( uint8_t space, uint8_t type )const
      {
         return _exclude_types.find( uint16_t( uint16_t(space) << 8 | type ) )
                != _exclude_types.end();
      }

      graphene::chain::database& database() { return _plugin.database(); }

      pg_indexer_plugin& _plugin;
      writer_options     _writer_options;
      uint32_t           _start_block = 0;
      bool               _irreversible_only = false;
      bool               _sync_state_on_startup = false;
      fc::flat_set<uint16_t> _exclude_types; ///< (space << 8) | type

      std::unique_ptr<pg_writer> _writer;
      std::unique_ptr<block_bundle> _open_bundle;

      /// irreversible-only mode: bundles held here until the chain confirms them
      std::deque<block_bundle> _lib_buffer;

      // last block captured on the main thread (reorg detection)
      uint32_t    _last_captured_num = 0;
      std::string _last_captured_id;

      std::vector<boost::signals2::scoped_connection> _connections;
};

void pg_indexer_plugin_impl::on_applied_block( const signed_block& b )
{
   if( _writer->fatal() )
      FC_THROW_EXCEPTION( graphene::chain::plugin_exception,
                          "pg_indexer: writer is in a fatal state, refusing to advance the chain" );

   // Ordering guarantee: any bundle still open belongs to a previous block
   flush_open_bundle();

   auto bundle = std::unique_ptr<block_bundle>( new block_bundle() );
   bundle->block_num = b.block_num();
   bundle->block_id = b.id().str();
   bundle->previous = b.previous.str();
   bundle->timestamp = b.timestamp;
   bundle->witness_instance = b.witness.instance.value;
   bundle->witness_signature = fc::variant( b.witness_signature, 1 ).as_string();

   // Note: replay-vs-reorg discrimination happens on the writer thread, which can
   // compare an incoming block id against what is stored in PostgreSQL. Here we
   // only capture.
   _last_captured_num = bundle->block_num;
   _last_captured_id = bundle->block_id;

   auto& db = database();

   // transactions
   bundle->txs.reserve( b.transactions.size() );
   for( const auto& tx : b.transactions )
   {
      tx_entry entry;
      entry.trx_id = tx.id().str();
      entry.ref_block_num = tx.ref_block_num;
      entry.ref_block_prefix = tx.ref_block_prefix;
      entry.expiration = tx.expiration;
      entry.operation_count = uint32_t( tx.operations.size() );
      fc::to_variant( tx.signatures, entry.signatures_v, FC_PACK_MAX_DEPTH );
      bundle->txs.push_back( std::move(entry) );
   }

   // operations, including virtual ones. get_applied_operations() is cleared
   // right after this signal returns, so everything is copied out here.
   const auto& hist = db.get_applied_operations();
   bundle->ops.reserve( hist.size() );
   for( const auto& o_op : hist )
   {
      if( !o_op.valid() )
         continue;
      const auto& oh = *o_op;

      op_entry entry;
      entry.trx_in_block = oh.trx_in_block;
      entry.op_in_trx = oh.op_in_trx;
      entry.virtual_op = int32_t( oh.virtual_op );
      entry.is_virtual = oh.is_virtual;
      entry.op_type = int16_t( oh.op.which() );
      entry.fee_payer_instance = oh.op.visit( get_fee_payer_visitor() ).instance.value;
      oh.op.visit( fc::from_static_variant( entry.op_v, FC_PACK_MAX_DEPTH ) );
      fc::to_variant( oh.result, entry.result_v, FC_PACK_MAX_DEPTH );

      // impacted accounts - same recipe as the elasticsearch plugin
      fc::flat_set<account_id_type> impacted;
      std::vector<authority> other;
      operation_get_required_authorities( oh.op, impacted, impacted, other,
            MUST_IGNORE_CUSTOM_OP_REQD_AUTHS( db.head_block_time() ) );

      if( oh.op.is_type<account_create_operation>() )
         impacted.insert( account_id_type( oh.result.get<object_id_type>() ) );

      if( HARDFORK_CORE_265_PASSED( b.timestamp ) || !oh.op.is_type<account_create_operation>() )
         operation_get_impacted_accounts( oh.op, impacted,
               MUST_IGNORE_CUSTOM_OP_REQD_AUTHS( db.head_block_time() ) );

      if( oh.result.is_type<extendable_operation_result>() )
      {
         const auto& op_result = oh.result.get<extendable_operation_result>();
         if( op_result.value.impacted_accounts.valid() )
            for( const auto& account : *op_result.value.impacted_accounts )
               impacted.insert( account );
      }

      for( const auto& auth : other )
         for( const auto& item : auth.account_auths )
            impacted.insert( item.first );

      for( const auto& account : impacted )
         entry.impacted_accounts.insert( account.instance.value );

      bundle->ops.push_back( std::move(entry) );
   }

   _open_bundle = std::move( bundle );

   // The object-delta signals fire synchronously after applied_block within the
   // same _apply_block call; this async task runs after all of them (and after
   // the undo session commits), which makes it the block-complete flush point.
   fc::async( [this]() { flush_open_bundle(); } );
}

void pg_indexer_plugin_impl::on_objects_delta( char kind, const std::vector<object_id_type>& ids )
{
   // Deltas only make sense in the context of the block being applied; anything
   // outside (genesis initialization etc.) is covered by startup reconciliation.
   if( !_open_bundle )
      return;

   auto& db = database();
   for( const auto& id : ids )
   {
      if( is_excluded( id.space(), id.type() ) )
         continue;
      delta_entry entry;
      entry.space = id.space();
      entry.type = id.type();
      entry.instance = id.instance();
      entry.kind = kind;
      if( kind != 'r' )
      {
         const auto* obj = db.find_object( id );
         if( obj == nullptr )
            continue; // created and removed within the same block
         entry.state_v = obj->to_variant();
      }
      _open_bundle->deltas.push_back( std::move(entry) );
   }
}

void pg_indexer_plugin_impl::enqueue_reconcile_bundle()
{
   auto& db = database();
   block_bundle bundle;
   bundle.reconcile = true;
   bundle.block_num = db.head_block_num();
   bundle.timestamp = db.head_block_time();

   for( uint8_t space : { uint8_t(1), uint8_t(2) } )
   {
      for( uint16_t type = 0; type < 64; ++type )
      {
         if( is_excluded( space, uint8_t(type) ) )
            continue;
         try
         {
            const auto& idx = db.get_index( space, uint8_t(type) );
            idx.inspect_all_objects( [&]( const graphene::db::object& obj )
            {
               delta_entry entry;
               entry.space = space;
               entry.type = uint8_t(type);
               entry.instance = obj.id.instance();
               entry.kind = 's';
               entry.state_v = obj.to_variant();
               bundle.deltas.push_back( std::move(entry) );
            });
         }
         catch( const fc::exception& )
         {
            continue; // no index registered for this (space, type)
         }
      }
   }

   ilog( "pg_indexer: state reconciliation snapshot at block ${b}: ${n} live objects",
         ("b", bundle.block_num)("n", bundle.deltas.size()) );
   _writer->enqueue( std::move(bundle) );
}

void pg_indexer_plugin_impl::flush_open_bundle()
{
   if( !_open_bundle )
      return;
   std::unique_ptr<block_bundle> bundle = std::move( _open_bundle );
   if( bundle->block_num < _start_block && bundle->rollback_from == 0 )
      return;

   if( !_irreversible_only )
   {
      _writer->enqueue( std::move( *bundle ) );
      return;
   }

   // Fork switches simply replace the not-yet-released bundles in the buffer;
   // nothing below the last irreversible block can ever be popped, so PostgreSQL
   // never sees a rollback in this mode.
   while( !_lib_buffer.empty() && _lib_buffer.back().block_num >= bundle->block_num )
      _lib_buffer.pop_back();
   _lib_buffer.push_back( std::move( *bundle ) );

   const uint32_t last_irreversible =
      database().get_dynamic_global_properties().last_irreversible_block_num;
   while( !_lib_buffer.empty() && _lib_buffer.front().block_num <= last_irreversible )
   {
      _writer->enqueue( std::move( _lib_buffer.front() ) );
      _lib_buffer.pop_front();
   }
}

} // namespace detail

pg_indexer_plugin::pg_indexer_plugin( graphene::app::application& app )
   : plugin( app ), my( new detail::pg_indexer_plugin_impl( *this ) )
{
}

pg_indexer_plugin::~pg_indexer_plugin() = default;

std::string pg_indexer_plugin::plugin_name()const
{
   return "pg_indexer";
}

std::string pg_indexer_plugin::plugin_description()const
{
   return "Indexes blocks, transactions, operations, object history and typed "
          "projections into PostgreSQL.";
}

void pg_indexer_plugin::plugin_set_program_options(
   boost::program_options::options_description& cli,
   boost::program_options::options_description& cfg )
{
   namespace bpo = boost::program_options;
   cli.add_options()
      ( "pg-indexer-connection-url",
        bpo::value<std::string>()->default_value( "postgresql://localhost/swaplock" ),
        "PostgreSQL connection URL or conninfo string" )
      ( "pg-indexer-bulk-replay", bpo::value<uint32_t>()->default_value( 1000 ),
        "Max blocks per SQL transaction while replaying / far from head" )
      ( "pg-indexer-bulk-sync", bpo::value<uint32_t>()->default_value( 1 ),
        "Max blocks per SQL transaction when synced" )
      ( "pg-indexer-queue-capacity", bpo::value<uint32_t>()->default_value( 4096 ),
        "Bundles buffered before applying backpressure to block application" )
      ( "pg-indexer-start-block", bpo::value<uint32_t>()->default_value( 0 ),
        "Do not index blocks below this number" )
      ( "pg-indexer-irreversible-only", bpo::value<bool>()->default_value( false ),
        "Only index blocks that became irreversible (no reorg handling needed)" )
      ( "pg-indexer-object-types-exclude",
        bpo::value<std::string>()->default_value( "2.1,2.8,2.9,1.11,2.7" ),
        "Comma-separated space.type list excluded from the temporal object history "
        "(default: dynamic global properties, block summaries and the history-plugin "
        "bookkeeping objects, which duplicate the raw operations layer)" )
      ( "pg-indexer-sync-state-on-startup", bpo::value<bool>()->default_value( false ),
        "Reconcile the temporal object history with the live chain state at startup "
        "(always done when the object history is empty)" )
      ( "pg-indexer-on-error", bpo::value<std::string>()->default_value( "exit" ),
        "What to do when PostgreSQL keeps failing: 'exit' stops the node, "
        "'retry' retries forever (pausing block application)" )
      ( "pg-indexer-retry-seconds", bpo::value<uint32_t>()->default_value( 30 ),
        "How long to retry a failing write before honoring pg-indexer-on-error" )
      ;
   cfg.add( cli );
}

void pg_indexer_plugin::plugin_initialize( const boost::program_options::variables_map& options )
{
   // options may lack entries when the plugin is driven programmatically (tests)
   auto opt_string = [&options]( const char* name, const std::string& fallback ) {
      return options.count( name ) != 0 && !options[name].empty()
             ? options[name].as<std::string>() : fallback;
   };
   auto opt_uint32 = [&options]( const char* name, uint32_t fallback ) {
      return options.count( name ) != 0 && !options[name].empty()
             ? options[name].as<uint32_t>() : fallback;
   };
   auto opt_bool = [&options]( const char* name, bool fallback ) {
      return options.count( name ) != 0 && !options[name].empty()
             ? options[name].as<bool>() : fallback;
   };

   my->_writer_options.connection_url =
      opt_string( "pg-indexer-connection-url", "postgresql://localhost/swaplock" );
   my->_writer_options.bulk_replay = opt_uint32( "pg-indexer-bulk-replay", 1000 );
   my->_writer_options.bulk_sync = opt_uint32( "pg-indexer-bulk-sync", 1 );
   my->_writer_options.queue_capacity = opt_uint32( "pg-indexer-queue-capacity", 4096 );
   my->_writer_options.retry_seconds = opt_uint32( "pg-indexer-retry-seconds", 30 );
   my->_start_block = opt_uint32( "pg-indexer-start-block", 0 );
   my->_irreversible_only = opt_bool( "pg-indexer-irreversible-only", false );
   my->_sync_state_on_startup = opt_bool( "pg-indexer-sync-state-on-startup", false );

   const std::string exclude_list =
      opt_string( "pg-indexer-object-types-exclude", "2.1,2.8,2.9,1.11,2.7" );
   for( size_t pos = 0; pos < exclude_list.size(); )
   {
      size_t comma = exclude_list.find( ',', pos );
      if( comma == std::string::npos )
         comma = exclude_list.size();
      const std::string item = exclude_list.substr( pos, comma - pos );
      pos = comma + 1;
      if( item.empty() )
         continue;
      size_t dot = item.find( '.' );
      FC_ASSERT( dot != std::string::npos,
                 "pg-indexer-object-types-exclude entries must look like 'space.type', got '${i}'",
                 ("i", item) );
      my->_exclude_types.insert( uint16_t(
         ( std::stoul( item.substr( 0, dot ) ) << 8 ) | std::stoul( item.substr( dot + 1 ) ) ) );
   }

   const std::string on_error = opt_string( "pg-indexer-on-error", "exit" );
   FC_ASSERT( on_error == "exit" || on_error == "retry",
              "pg-indexer-on-error must be 'exit' or 'retry'" );
   my->_writer_options.fail_fast = ( on_error == "exit" );

   // Connect and start the writer already during initialization: with a replay
   // (--replay-blockchain) the applied_block signal fires for every historical
   // block long before plugin_startup runs.
   my->_writer.reset( new pg_writer( my->_writer_options ) );
   my->_writer->initialize();
   my->_last_captured_num = my->_writer->last_indexed_block();
   my->_last_captured_id = my->_writer->last_indexed_block_id();
   my->_writer->start();

   my->_connections.emplace_back( database().applied_block.connect( 0,
      [this]( const signed_block& b ) { my->on_applied_block( b ); } ) );
   my->_connections.emplace_back( database().new_objects.connect(
      [this]( const std::vector<object_id_type>& ids, const fc::flat_set<account_id_type>& )
      { my->on_objects_delta( 'c', ids ); } ) );
   my->_connections.emplace_back( database().changed_objects.connect(
      [this]( const std::vector<object_id_type>& ids, const fc::flat_set<account_id_type>& )
      { my->on_objects_delta( 'u', ids ); } ) );
   my->_connections.emplace_back( database().removed_objects.connect(
      [this]( const std::vector<object_id_type>& ids, const std::vector<const object*>&,
              const fc::flat_set<account_id_type>& )
      { my->on_objects_delta( 'r', ids ); } ) );

   ilog( "pg_indexer: initialized (url: ${u})", ("u", my->_writer_options.connection_url) );
}

void pg_indexer_plugin::plugin_startup()
{
   // Runs after a possible reindex. Blocks below the undo point are replayed
   // without the object-delta signals, so the temporal layer reconciles against
   // the live state here; always needed when the object history starts empty.
   if( my->_sync_state_on_startup || my->_writer->object_history_empty() )
      my->enqueue_reconcile_bundle();
}

void pg_indexer_plugin::plugin_shutdown()
{
   my->_connections.clear();
   my->flush_open_bundle();
   if( my->_irreversible_only && !my->_lib_buffer.empty() )
      ilog( "pg_indexer: dropping ${n} not-yet-irreversible buffered blocks on shutdown; "
            "restart with --replay-blockchain to backfill them once they confirm",
            ("n", my->_lib_buffer.size()) );
   if( my->_writer )
      my->_writer->stop();
}

} } // graphene::pg_indexer
