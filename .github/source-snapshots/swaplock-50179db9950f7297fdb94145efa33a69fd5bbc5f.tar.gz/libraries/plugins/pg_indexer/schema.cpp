/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <graphene/pg_indexer/schema.hpp>
#include <graphene/pg_indexer/pg_client.hpp>

#include <fc/exception/exception.hpp>
#include <fc/log/logger.hpp>

#include <string>
#include <vector>

namespace graphene { namespace pg_indexer {

namespace {

const std::vector<const char*> MIGRATIONS = {
// ============================== V1 ==============================
R"SQL(
CREATE SCHEMA IF NOT EXISTS pgx;

CREATE TABLE pgx.schema_migrations (
  version    int PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now());

-- indexer bookkeeping (single row)
CREATE TABLE pgx.indexer_state (
  id            smallint PRIMARY KEY CHECK (id = 1),
  last_block    bigint NOT NULL,
  last_block_id text NOT NULL,
  next_op_seq   bigint NOT NULL);
INSERT INTO pgx.indexer_state (id, last_block, last_block_id, next_op_seq)
  VALUES (1, 0, '', 1);

-- ============ Layer 1: raw ============
CREATE TABLE pgx.blocks (
  block_num  bigint PRIMARY KEY,
  block_id   text NOT NULL,
  previous   text NOT NULL,
  timestamp  timestamptz NOT NULL,
  witness    bigint NOT NULL,
  tx_count   int NOT NULL,
  witness_signature text NOT NULL);
CREATE INDEX blocks_ts_idx ON pgx.blocks (timestamp);

CREATE TABLE pgx.transactions (
  block_num        bigint NOT NULL,
  trx_in_block     int    NOT NULL,
  trx_id           text   NOT NULL,
  ref_block_num    int    NOT NULL,
  ref_block_prefix bigint NOT NULL,
  expiration       timestamptz NOT NULL,
  operation_count  int    NOT NULL,
  signatures       jsonb  NOT NULL,
  PRIMARY KEY (block_num, trx_in_block));
CREATE INDEX transactions_trx_id_idx ON pgx.transactions (trx_id);

CREATE TABLE pgx.operations (
  op_seq       bigint PRIMARY KEY,
  block_num    bigint NOT NULL,
  trx_in_block int    NOT NULL,
  op_in_trx    int    NOT NULL,
  virtual_op   int    NOT NULL,
  is_virtual   boolean NOT NULL,
  op_type      smallint NOT NULL,
  fee_payer    bigint NOT NULL,
  block_time   timestamptz NOT NULL,
  op           jsonb NOT NULL,
  result       jsonb NOT NULL,
  UNIQUE (block_num, trx_in_block, op_in_trx, virtual_op));
CREATE INDEX operations_block_idx  ON pgx.operations (block_num);
CREATE INDEX operations_type_idx   ON pgx.operations (op_type, block_num);
CREATE INDEX operations_payer_idx  ON pgx.operations (fee_payer, op_seq);
CREATE INDEX operations_op_gin_idx ON pgx.operations USING gin (op jsonb_path_ops);

CREATE TABLE pgx.account_operations (
  account_id bigint NOT NULL,
  sequence   bigint NOT NULL,
  op_seq     bigint NOT NULL,
  block_num  bigint NOT NULL,
  PRIMARY KEY (account_id, sequence));
CREATE INDEX account_operations_block_idx ON pgx.account_operations (block_num);
CREATE INDEX account_operations_op_idx    ON pgx.account_operations (op_seq);

-- ============ Layer 2: generic temporal (SCD2) ============
CREATE TABLE pgx.object_history (
  object_space    smallint NOT NULL,
  object_type     smallint NOT NULL,
  object_instance bigint   NOT NULL,
  object_id text GENERATED ALWAYS AS
    (object_space::text||'.'||object_type::text||'.'||object_instance::text) STORED,
  state            jsonb,
  change_kind      char(1) NOT NULL CHECK (change_kind IN ('c','u','r','s')),
  valid_from_block bigint NOT NULL,
  valid_to_block   bigint,
  block_time       timestamptz NOT NULL,
  PRIMARY KEY (object_space, object_type, object_instance, valid_from_block));
CREATE UNIQUE INDEX object_history_current_idx ON pgx.object_history
  (object_space, object_type, object_instance) WHERE valid_to_block IS NULL;
CREATE INDEX object_history_from_idx ON pgx.object_history (valid_from_block);
CREATE INDEX object_history_to_idx   ON pgx.object_history (valid_to_block)
  WHERE valid_to_block IS NOT NULL;

CREATE VIEW pgx.v_objects_current AS
  SELECT * FROM pgx.object_history
  WHERE valid_to_block IS NULL AND change_kind <> 'r';

-- ============ Layer 3: typed projections (current state) ============
CREATE TABLE pgx.accounts (
  id bigint PRIMARY KEY,
  name text NOT NULL UNIQUE,
  registrar bigint NOT NULL,
  referrer bigint NOT NULL,
  owner_auth jsonb NOT NULL,
  active_auth jsonb NOT NULL,
  memo_key text,
  last_updated_block bigint NOT NULL);

CREATE TABLE pgx.assets (
  id bigint PRIMARY KEY,
  symbol text NOT NULL UNIQUE,
  issuer bigint NOT NULL,
  precision smallint NOT NULL,
  max_supply bigint NOT NULL,
  is_bitasset boolean NOT NULL,
  options jsonb NOT NULL,
  last_updated_block bigint NOT NULL);

CREATE TABLE pgx.balances (
  id         bigint PRIMARY KEY,
  account_id bigint NOT NULL,
  asset_id   bigint NOT NULL,
  amount     bigint NOT NULL,
  last_updated_block bigint NOT NULL,
  UNIQUE (account_id, asset_id));
CREATE INDEX balances_asset_idx ON pgx.balances (asset_id) WHERE amount > 0;

CREATE TABLE pgx.limit_orders (
  id bigint PRIMARY KEY,
  seller bigint NOT NULL,
  sell_asset bigint NOT NULL,
  receive_asset bigint NOT NULL,
  for_sale bigint NOT NULL,
  sell_price_base_amount  bigint NOT NULL,
  sell_price_quote_amount bigint NOT NULL,
  price numeric,
  expiration timestamptz NOT NULL,
  last_updated_block bigint NOT NULL);
CREATE INDEX limit_orders_market_idx ON pgx.limit_orders (sell_asset, receive_asset, price);

CREATE TABLE pgx.data_rooms (
  id bigint PRIMARY KEY,
  owner bigint NOT NULL,
  name text NOT NULL,
  description text NOT NULL,
  subject_which smallint NOT NULL,
  subject_instance bigint NOT NULL,
  encrypted boolean NOT NULL,
  current_epoch int NOT NULL,
  created timestamptz NOT NULL,
  last_updated_block bigint NOT NULL,
  UNIQUE (owner, name));
CREATE INDEX data_rooms_subject_idx ON pgx.data_rooms (subject_which, subject_instance);

-- A data room member is an account, a bare public key, or ANOTHER data room
-- (data_room_member_ref). member_which is the variant tag: 0 = account, 1 = public key,
-- 2 = data room (the keyring; see migration V5). The unused sides carry sentinels
-- rather than NULL, because NULLs compare as distinct and would defeat UNIQUE.
-- member_key is the room key encrypted to the member - not the member's own key; the
-- member's public key, when it has one, is member_key_pub.
CREATE TABLE pgx.data_room_members (
  id bigint PRIMARY KEY,
  room bigint NOT NULL,
  member_which smallint NOT NULL,
  member_account bigint NOT NULL,
  member_key_pub text NOT NULL,
  member_key text NOT NULL,
  permissions int NOT NULL,
  added timestamptz NOT NULL,
  last_updated_block bigint NOT NULL,
  -- DEFERRABLE, because a member can be replaced within ONE block: an atomic
  -- [member_remove, member_add] (re-admitting somebody with historical epoch
  -- keys) deletes the old member object and creates a new one with a new id
  -- but the SAME (room, member, key) tuple. The whole block is one
  -- transaction; a non-deferrable unique fires mid-transaction, before the
  -- delete of the old row runs, and wedges the indexer. Checked at COMMIT, the
  -- old row is already gone and the tuple is unique again.
  UNIQUE (room, member_which, member_account, member_key_pub)
    DEFERRABLE INITIALLY DEFERRED);
CREATE INDEX data_room_members_account_idx ON pgx.data_room_members (member_account)
  WHERE member_which = 0;
-- "which rooms may this key read" - the query a process holding only a key needs
CREATE INDEX data_room_members_key_idx ON pgx.data_room_members (member_key_pub)
  WHERE member_which = 1;

CREATE TABLE pgx.data_room_key_epochs (
  id bigint PRIMARY KEY,
  room bigint NOT NULL,
  epoch int NOT NULL,
  member_which smallint NOT NULL,
  member_account bigint NOT NULL,
  member_key_pub text NOT NULL,
  key text NOT NULL,
  last_updated_block bigint NOT NULL,
  -- DEFERRABLE for the same reason as data_room_members: re-admitting a member
  -- with epoch keys replaces their per-epoch envelope objects in one block
  -- (old ids deleted, new ids created for the same room/epoch/member). The
  -- unique must be checked at COMMIT, not mid-transaction, or the batch dies on
  -- a duplicate that the block's own delete is about to remove.
  UNIQUE (room, epoch, member_which, member_account, member_key_pub)
    DEFERRABLE INITIALLY DEFERRED);
CREATE INDEX data_room_key_epochs_key_idx ON pgx.data_room_key_epochs (member_key_pub)
  WHERE member_which = 1;

-- The author is a data_room_member_ref too: a key can author cards while an account pays
CREATE TABLE pgx.content_cards (
  id bigint PRIMARY KEY,
  author_which smallint NOT NULL,
  author_account bigint NOT NULL,
  author_key_pub text NOT NULL,
  room bigint NOT NULL,
  hash text NOT NULL,
  url text NOT NULL,
  type text NOT NULL,
  description text NOT NULL,
  content_key text NOT NULL,
  storage_data text NOT NULL,
  key_epoch int NOT NULL,
  created timestamptz NOT NULL,
  updated timestamptz NOT NULL,
  last_updated_block bigint NOT NULL,
  search tsvector GENERATED ALWAYS AS (
    to_tsvector('simple',
      coalesce(description,'') || ' ' || coalesce(type,'') || ' ' || coalesce(url,''))) STORED);
CREATE INDEX content_cards_search_idx ON pgx.content_cards USING gin (search);
CREATE INDEX content_cards_room_hash_idx ON pgx.content_cards (room, hash);
CREATE INDEX content_cards_room_idx   ON pgx.content_cards (room);
CREATE INDEX content_cards_author_idx ON pgx.content_cards (author_account)
  WHERE author_which = 0;
CREATE INDEX content_cards_author_key_idx ON pgx.content_cards (author_key_pub)
  WHERE author_which = 1;

-- One card granted to one recipient outside room membership. `key` is the card's
-- content key encrypted to the grantee; grants survive key rotation and disappear
-- with their card (also on a content change of the card) and with their room.
CREATE TABLE pgx.content_card_grants (
  id bigint PRIMARY KEY,
  card bigint NOT NULL,
  grantee_which smallint NOT NULL,
  grantee_account bigint NOT NULL,
  grantee_key_pub text NOT NULL,
  key text NOT NULL,
  granted_by bigint NOT NULL,
  created timestamptz NOT NULL,
  last_updated_block bigint NOT NULL,
  UNIQUE (card, grantee_which, grantee_account, grantee_key_pub));
CREATE INDEX content_card_grants_grantee_idx ON pgx.content_card_grants (grantee_account)
  WHERE grantee_which = 0;
CREATE INDEX content_card_grants_grantee_key_idx ON pgx.content_card_grants (grantee_key_pub)
  WHERE grantee_which = 1;
CREATE INDEX content_card_grants_granted_by_idx ON pgx.content_card_grants (granted_by);

CREATE TABLE pgx.market_trades (
  op_seq bigint PRIMARY KEY,
  block_num bigint NOT NULL,
  block_time timestamptz NOT NULL,
  account bigint NOT NULL,
  order_type smallint NOT NULL,
  order_instance bigint NOT NULL,
  pays_asset bigint NOT NULL,
  pays_amount bigint NOT NULL,
  receives_asset bigint NOT NULL,
  receives_amount bigint NOT NULL,
  fill_price_base_amount  bigint NOT NULL,
  fill_price_base_asset   bigint NOT NULL,
  fill_price_quote_amount bigint NOT NULL,
  fill_price_quote_asset  bigint NOT NULL,
  price numeric,
  is_maker boolean NOT NULL);
CREATE INDEX market_trades_market_time_idx ON pgx.market_trades
  (LEAST(pays_asset, receives_asset), GREATEST(pays_asset, receives_asset), block_time);
CREATE INDEX market_trades_block_idx ON pgx.market_trades (block_num);

-- ============ Views ============
CREATE VIEW pgx.v_order_book AS
  SELECT o.sell_asset, o.receive_asset,
         sa.symbol AS sell_symbol, ra.symbol AS receive_symbol,
         o.price, o.id AS order_id, o.seller, o.for_sale,
         o.for_sale::numeric / power(10::numeric, sa.precision) AS for_sale_units,
         o.expiration
  FROM pgx.limit_orders o
  JOIN pgx.assets sa ON sa.id = o.sell_asset
  JOIN pgx.assets ra ON ra.id = o.receive_asset;

-- One row per economic fill (the maker side; every fill emits a maker and a taker
-- fill_order operation). Price normalized to "asset_a units per one asset_b unit".
CREATE VIEW pgx.v_ohlcv_1m AS
  SELECT asset_a, asset_b,
         date_trunc('minute', block_time) AS bucket,
         (array_agg(price_ab ORDER BY op_seq))[1]      AS open,
         max(price_ab) AS high,
         min(price_ab) AS low,
         (array_agg(price_ab ORDER BY op_seq DESC))[1] AS close,
         sum(amount_a) AS volume_a,
         count(*) AS trades
  FROM (
    SELECT mt.op_seq, mt.block_time,
           LEAST(mt.pays_asset, mt.receives_asset)    AS asset_a,
           GREATEST(mt.pays_asset, mt.receives_asset) AS asset_b,
           CASE WHEN mt.pays_asset < mt.receives_asset
                THEN mt.pays_amount ELSE mt.receives_amount END AS amount_a,
           ( (CASE WHEN mt.pays_asset < mt.receives_asset
                   THEN mt.pays_amount ELSE mt.receives_amount END)::numeric
             * power(10::numeric, ab.precision) )
           / NULLIF( (CASE WHEN mt.pays_asset < mt.receives_asset
                           THEN mt.receives_amount ELSE mt.pays_amount END)::numeric
                     * power(10::numeric, aa.precision), 0 ) AS price_ab
    FROM pgx.market_trades mt
    JOIN pgx.assets aa ON aa.id = LEAST(mt.pays_asset, mt.receives_asset)
    JOIN pgx.assets ab ON ab.id = GREATEST(mt.pays_asset, mt.receives_asset)
    WHERE mt.is_maker
  ) t
  GROUP BY 1, 2, 3;
)SQL",
// ============================== V2 ==============================
// Typed projection of proposal_object (1.10.x) - the multisig approval queue.
// Approval sets are flattened to arrays so "proposals awaiting account X" is a
// GIN-indexed containment query; the wrapped transaction stays as raw JSONB.
R"SQL(
CREATE TABLE pgx.proposals (
  id bigint PRIMARY KEY,
  proposer bigint NOT NULL,
  expiration_time timestamptz NOT NULL,
  review_period_time timestamptz,
  proposed_transaction jsonb NOT NULL,
  required_active bigint[] NOT NULL DEFAULT '{}',
  available_active bigint[] NOT NULL DEFAULT '{}',
  required_owner bigint[] NOT NULL DEFAULT '{}',
  available_owner bigint[] NOT NULL DEFAULT '{}',
  available_keys text[] NOT NULL DEFAULT '{}',
  fail_reason text NOT NULL DEFAULT '',
  last_updated_block bigint NOT NULL);
CREATE INDEX proposals_proposer_idx   ON pgx.proposals (proposer);
CREATE INDEX proposals_expiration_idx ON pgx.proposals (expiration_time);
CREATE INDEX proposals_required_active_gin ON pgx.proposals USING gin (required_active);
CREATE INDEX proposals_required_owner_gin  ON pgx.proposals USING gin (required_owner);

-- Audit trail: executed/expired proposals leave pgx.proposals (current state) but
-- every version, including the terminal one, stays in object_history. This view is
-- the compliance answer to "what happened to proposal X and when".
CREATE VIEW pgx.v_proposals_history AS
  SELECT object_instance AS id,
         state,
         change_kind,
         valid_from_block,
         valid_to_block,
         block_time
  FROM pgx.object_history
  WHERE object_space = 1 AND object_type = 10;
)SQL",
// ============================== V3 ==============================
// Make the data-room composite uniques DEFERRABLE. A member re-admitted with
// historical epoch keys is an atomic [member_remove, member_add] in ONE block:
// the old member and its per-epoch envelope objects are deleted and new ones
// created with new ids but the SAME (room, member[, epoch]) tuple. The whole
// block writes in a single transaction; a non-deferrable unique fires the
// instant the new row is inserted - before the block's own delete of the old
// row runs - and wedges the indexer on that block forever. Deferred to COMMIT,
// the old row is already gone. Idempotent: safe on a DB fixed by hand and on a
// fresh one whose base schema already declares them deferrable.
R"SQL(
ALTER TABLE pgx.data_room_members
  DROP CONSTRAINT IF EXISTS data_room_members_room_member_which_member_account_member_k_key;
ALTER TABLE pgx.data_room_members
  ADD CONSTRAINT data_room_members_room_member_which_member_account_member_k_key
  UNIQUE (room, member_which, member_account, member_key_pub)
  DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE pgx.data_room_key_epochs
  DROP CONSTRAINT IF EXISTS data_room_key_epochs_room_epoch_member_which_member_account_key;
ALTER TABLE pgx.data_room_key_epochs
  ADD CONSTRAINT data_room_key_epochs_room_epoch_member_which_member_account_key
  UNIQUE (room, epoch, member_which, member_account, member_key_pub)
  DEFERRABLE INITIALLY DEFERRED;
)SQL"
,
// ---------------------------------------------------------------------------
// V4 - content card links: one card embedded into other rooms by reference.
// The card stays in its home room; a link re-wraps its content key to the
// target room's key. `card_epoch` shows whether the wrap is stale.
// ---------------------------------------------------------------------------
R"SQL(
CREATE TABLE pgx.content_card_links (
  id bigint PRIMARY KEY,
  card bigint NOT NULL,
  room bigint NOT NULL,
  linker_which smallint NOT NULL,
  linker_account bigint NOT NULL,
  linker_key_pub text NOT NULL,
  link_key text NOT NULL,
  link_epoch int NOT NULL,
  card_epoch int NOT NULL,
  created timestamptz NOT NULL,
  last_updated_block bigint NOT NULL,
  UNIQUE (room, card));
CREATE INDEX content_card_links_card_idx ON pgx.content_card_links (card);
CREATE INDEX content_card_links_room_idx ON pgx.content_card_links (room);
)SQL"
,
// ---------------------------------------------------------------------------
// V5 - keyring: a data room may itself be a MEMBER of another room
// (member_which = 2, the grantor room's key wrapped with the grantee room's
// key). member_room carries the grantee room instance; the sentinel stays 0
// for account and key members. The UNIQUE constraints must include it, or two
// different room members of one room would collide on (which=2, 0, '').
// ---------------------------------------------------------------------------
R"SQL(
ALTER TABLE pgx.data_room_members ADD COLUMN member_room bigint NOT NULL DEFAULT 0;
ALTER TABLE pgx.data_room_key_epochs ADD COLUMN member_room bigint NOT NULL DEFAULT 0;

ALTER TABLE pgx.data_room_members
  DROP CONSTRAINT IF EXISTS data_room_members_room_member_which_member_account_member_k_key;
ALTER TABLE pgx.data_room_members
  ADD CONSTRAINT data_room_members_room_member_which_member_account_member_k_key
  UNIQUE (room, member_which, member_account, member_key_pub, member_room)
  DEFERRABLE INITIALLY DEFERRED;

ALTER TABLE pgx.data_room_key_epochs
  DROP CONSTRAINT IF EXISTS data_room_key_epochs_room_epoch_member_which_member_account_key;
ALTER TABLE pgx.data_room_key_epochs
  ADD CONSTRAINT data_room_key_epochs_room_epoch_member_which_member_account_key
  UNIQUE (room, epoch, member_which, member_account, member_key_pub, member_room)
  DEFERRABLE INITIALLY DEFERRED;

CREATE INDEX data_room_members_member_room_idx
  ON pgx.data_room_members (member_room) WHERE member_which = 2;
)SQL"
};

} // anonymous namespace

void ensure_schema( pg_client& db )
{
   // one migration runner at a time
   db.exec( "SELECT pg_advisory_lock(772020261)" );
   try
   {
      int current_version = 0;
      auto migrations_exist = db.query(
            "SELECT 1 FROM information_schema.tables"
            " WHERE table_schema = 'pgx' AND table_name = 'schema_migrations'" );
      if( migrations_exist.rows() > 0 )
      {
         auto version_result = db.query( "SELECT coalesce(max(version), 0) FROM pgx.schema_migrations" );
         current_version = std::stoi( version_result.value( 0, 0 ) );
      }

      for( size_t i = size_t(current_version); i < MIGRATIONS.size(); ++i )
      {
         ilog( "pg_indexer: applying schema migration V${v}", ("v", i + 1) );
         db.begin();
         try
         {
            db.exec( MIGRATIONS[i] );
            db.exec( "INSERT INTO pgx.schema_migrations (version) VALUES ("
                     + std::to_string( i + 1 ) + ")" );
            db.commit();
         }
         catch( ... )
         {
            db.rollback();
            throw;
         }
      }
   }
   catch( ... )
   {
      db.exec( "SELECT pg_advisory_unlock(772020261)" );
      throw;
   }
   db.exec( "SELECT pg_advisory_unlock(772020261)" );
}

} } // graphene::pg_indexer
