/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <graphene/pg_indexer/pg_client.hpp>

#include <fc/exception/exception.hpp>

#include <libpq-fe.h>

namespace graphene { namespace pg_indexer {

namespace {

/// Connection resilience defaults. Without TCP keepalives a peer that
/// vanishes without closing the connection (node failure, network partition)
/// leaves libpq blocked in recv() forever — the writer's retry loop never
/// runs. With these, a dead peer surfaces as an error within ~30s and the
/// existing retry/reconnect path takes over.
const std::pair<const char*, const char*> resilience_defaults[] = {
   { "keepalives",          "1"     },
   { "keepalives_idle",     "15"    },
   { "keepalives_interval", "5"     },
   { "keepalives_count",    "3"     },
   { "tcp_user_timeout",    "30000" },
   { "connect_timeout",     "10"    },
};

/// Appends the resilience defaults to a conninfo string, honoring values the
/// operator set explicitly. Handles both libpq forms: URI
/// (postgresql://...?k=v) and keyword/value ("host=... k=v").
std::string augment_conninfo( const std::string& conninfo )
{
   const bool is_uri = conninfo.rfind( "postgres://", 0 ) == 0
                       || conninfo.rfind( "postgresql://", 0 ) == 0;

   std::string result = conninfo;
   bool has_query = conninfo.find( '?' ) != std::string::npos;

   for( const auto& def : resilience_defaults )
   {
      // Match "name=" so e.g. an explicit keepalives_idle does not suppress
      // the keepalives default itself.
      if( conninfo.find( std::string( def.first ) + "=" ) != std::string::npos )
         continue; // operator override wins

      if( is_uri )
      {
         result += has_query ? "&" : "?";
         has_query = true;
         result += def.first;
         result += "=";
         result += def.second;
      }
      else
      {
         result += " ";
         result += def.first;
         result += "=";
         result += def.second;
      }
   }

   return result;
}

} // anonymous namespace

pg_result_holder::~pg_result_holder()
{
   if( _res != nullptr )
      PQclear( _res );
}

int pg_result_holder::rows()const { return PQntuples( _res ); }
int pg_result_holder::columns()const { return PQnfields( _res ); }
bool pg_result_holder::is_null( int row, int col )const { return 0 != PQgetisnull( _res, row, col ); }
std::string pg_result_holder::value( int row, int col )const { return PQgetvalue( _res, row, col ); }

pg_client::pg_client( std::string conninfo )
   : _conninfo( augment_conninfo( conninfo ) )
{
}

pg_client::~pg_client()
{
   disconnect();
}

void pg_client::connect()
{
   disconnect();
   _conn = PQconnectdb( _conninfo.c_str() );
   if( PQstatus( _conn ) != CONNECTION_OK )
   {
      std::string error = PQerrorMessage( _conn );
      disconnect();
      FC_THROW_EXCEPTION( fc::exception, "PostgreSQL connection failed: ${e}", ("e", error) );
   }
}

void pg_client::disconnect()
{
   if( _conn != nullptr )
   {
      PQfinish( _conn );
      _conn = nullptr;
   }
}

bool pg_client::connected()const
{
   return _conn != nullptr && PQstatus( _conn ) == CONNECTION_OK;
}

void pg_client::check_connection()
{
   FC_ASSERT( _conn != nullptr, "PostgreSQL client is not connected" );
}

void pg_client::exec( const std::string& sql )
{
   query( sql ); // result discarded; throws on error
}

pg_result_holder pg_client::query( const std::string& sql )
{
   check_connection();
   PGresult* res = PQexec( _conn, sql.c_str() );
   ExecStatusType status = PQresultStatus( res );
   if( status != PGRES_TUPLES_OK && status != PGRES_COMMAND_OK )
   {
      std::string error = PQresultErrorMessage( res );
      PQclear( res );
      FC_THROW_EXCEPTION( fc::exception, "PostgreSQL error: ${e} (query: ${q})",
                          ("e", error)("q", sql.substr(0, 500)) );
   }
   return pg_result_holder( res );
}

void pg_client::exec_params( const std::string& sql, const std::vector<std::string>& params,
                             const std::vector<bool>* nulls )
{
   check_connection();
   std::vector<const char*> values;
   values.reserve( params.size() );
   for( size_t i = 0; i < params.size(); ++i )
   {
      if( nulls != nullptr && (*nulls)[i] )
         values.push_back( nullptr );
      else
         values.push_back( params[i].c_str() );
   }
   PGresult* res = PQexecParams( _conn, sql.c_str(), int(values.size()), nullptr,
                                 values.data(), nullptr, nullptr, 0 );
   ExecStatusType status = PQresultStatus( res );
   if( status != PGRES_TUPLES_OK && status != PGRES_COMMAND_OK )
   {
      std::string error = PQresultErrorMessage( res );
      PQclear( res );
      FC_THROW_EXCEPTION( fc::exception, "PostgreSQL error: ${e} (statement: ${q})",
                          ("e", error)("q", sql.substr(0, 500)) );
   }
   PQclear( res );
}

void pg_client::begin() { query( "BEGIN" ); }
void pg_client::commit() { query( "COMMIT" ); }

void pg_client::rollback() noexcept
{
   if( _conn == nullptr )
      return;
   PGresult* res = PQexec( _conn, "ROLLBACK" );
   if( res != nullptr )
      PQclear( res );
}

std::string pg_client::literal( const std::string& text )
{
   check_connection();
   char* escaped = PQescapeLiteral( _conn, text.c_str(), text.size() );
   FC_ASSERT( escaped != nullptr, "PQescapeLiteral failed: ${e}", ("e", PQerrorMessage(_conn)) );
   std::string result( escaped );
   PQfreemem( escaped );
   return result;
}

} } // graphene::pg_indexer
