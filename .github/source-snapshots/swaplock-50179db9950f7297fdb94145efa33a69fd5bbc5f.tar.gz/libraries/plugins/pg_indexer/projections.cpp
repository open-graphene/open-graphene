/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <graphene/pg_indexer/projections.hpp>

namespace graphene { namespace pg_indexer {

namespace {

// object id string "1.2.100" -> instance 100
std::string inst( const std::string& id_expr )
{
   return "split_part(" + id_expr + ", '.', 3)::bigint";
}

// jsonb array of object id strings -> bigint[] of instances
std::string inst_array( const std::string& field )
{
   return "(SELECT coalesce(array_agg(split_part(v, '.', 3)::bigint), '{}')"
          " FROM jsonb_array_elements_text(s->'" + field + "') v)";
}

// A data_room_member_ref serializes as [which, value]: which 0 carries an account id string,
// which 1 a base58 public key. Split it into (which, account, key) with a sentinel on the
// unused side - NULLs would compare as distinct and defeat the UNIQUE constraints.
std::string member_which( const std::string& field )
{
   return "(s->'" + field + "'->>0)::smallint";
}
std::string member_account( const std::string& field )
{
   return "CASE WHEN (s->'" + field + "'->>0)::int = 0"
          " THEN " + inst( "s->'" + field + "'->>1" ) + " ELSE 0 END";
}
std::string member_key_pub( const std::string& field )
{
   return "CASE WHEN (s->'" + field + "'->>0)::int = 1"
          " THEN s->'" + field + "'->>1 ELSE '' END";
}
std::string member_room( const std::string& field )
{
   return "CASE WHEN (s->'" + field + "'->>0)::int = 2"
          " THEN " + inst( "s->'" + field + "'->>1" ) + " ELSE 0 END";
}

std::vector<projection_def> build_projections()
{
   std::vector<projection_def> defs;

   { // accounts (1.2)
      projection_def d;
      d.space = 1; d.type = 2;
      d.table = "pgx.accounts";
      d.columns = "id, name, registrar, referrer, owner_auth, active_auth, memo_key,"
                  " last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", s->>'name', " + inst("s->>'registrar'") + ", "
         + inst("s->>'referrer'") + ", s->'owner', s->'active',"
         " s->'options'->>'memo_key', blk";
      d.update_set =
         "name = EXCLUDED.name, registrar = EXCLUDED.registrar,"
         " referrer = EXCLUDED.referrer, owner_auth = EXCLUDED.owner_auth,"
         " active_auth = EXCLUDED.active_auth, memo_key = EXCLUDED.memo_key,"
         " last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }
   { // assets (1.3)
      projection_def d;
      d.space = 1; d.type = 3;
      d.table = "pgx.assets";
      d.columns = "id, symbol, issuer, precision, max_supply, is_bitasset, options,"
                  " last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", s->>'symbol', " + inst("s->>'issuer'") + ","
         " (s->>'precision')::smallint, (s->'options'->>'max_supply')::bigint,"
         " (s ? 'bitasset_data_id'), s->'options', blk";
      d.update_set =
         "symbol = EXCLUDED.symbol, issuer = EXCLUDED.issuer,"
         " precision = EXCLUDED.precision, max_supply = EXCLUDED.max_supply,"
         " is_bitasset = EXCLUDED.is_bitasset, options = EXCLUDED.options,"
         " last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }
   { // balances (2.5, account_balance_object)
      projection_def d;
      d.space = 2; d.type = 5;
      d.table = "pgx.balances";
      d.columns = "id, account_id, asset_id, amount, last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", " + inst("s->>'owner'") + ", "
         + inst("s->>'asset_type'") + ", (s->>'balance')::bigint, blk";
      d.update_set =
         "account_id = EXCLUDED.account_id, asset_id = EXCLUDED.asset_id,"
         " amount = EXCLUDED.amount, last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }
   { // limit orders (1.7)
      projection_def d;
      d.space = 1; d.type = 7;
      d.table = "pgx.limit_orders";
      d.columns = "id, seller, sell_asset, receive_asset, for_sale,"
                  " sell_price_base_amount, sell_price_quote_amount, price, expiration,"
                  " last_updated_block";
      // price = receive units per one sell unit, exact numeric arithmetic
      d.select_list =
         inst("s->>'id'") + ", " + inst("s->>'seller'") + ", "
         + inst("s->'sell_price'->'base'->>'asset_id'") + ", "
         + inst("s->'sell_price'->'quote'->>'asset_id'") + ","
         " (s->>'for_sale')::bigint,"
         " (s->'sell_price'->'base'->>'amount')::bigint,"
         " (s->'sell_price'->'quote'->>'amount')::bigint,"
         " ((s->'sell_price'->'quote'->>'amount')::numeric"
         "   * power(10::numeric, sell_a.precision))"
         "  / NULLIF((s->'sell_price'->'base'->>'amount')::numeric"
         "   * power(10::numeric, recv_a.precision), 0),"
         " (s->>'expiration')::timestamptz, blk";
      d.joins =
         " LEFT JOIN pgx.assets sell_a ON sell_a.id = "
         + inst("s->'sell_price'->'base'->>'asset_id'") +
         " LEFT JOIN pgx.assets recv_a ON recv_a.id = "
         + inst("s->'sell_price'->'quote'->>'asset_id'");
      d.update_set =
         "seller = EXCLUDED.seller, sell_asset = EXCLUDED.sell_asset,"
         " receive_asset = EXCLUDED.receive_asset, for_sale = EXCLUDED.for_sale,"
         " sell_price_base_amount = EXCLUDED.sell_price_base_amount,"
         " sell_price_quote_amount = EXCLUDED.sell_price_quote_amount,"
         " price = EXCLUDED.price, expiration = EXCLUDED.expiration,"
         " last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }
   { // proposals (1.10)
      projection_def d;
      d.space = 1; d.type = 10;
      d.table = "pgx.proposals";
      d.columns = "id, proposer, expiration_time, review_period_time,"
                  " proposed_transaction, required_active, available_active,"
                  " required_owner, available_owner, available_keys, fail_reason,"
                  " last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", " + inst("s->>'proposer'") + ","
         " (s->>'expiration_time')::timestamptz,"
         " (s->>'review_period_time')::timestamptz,"
         " s->'proposed_transaction', "
         + inst_array("required_active_approvals") + ", "
         + inst_array("available_active_approvals") + ", "
         + inst_array("required_owner_approvals") + ", "
         + inst_array("available_owner_approvals") + ","
         " (SELECT coalesce(array_agg(v), '{}')"
         "  FROM jsonb_array_elements_text(s->'available_key_approvals') v),"
         " coalesce(s->>'fail_reason', ''), blk";
      d.update_set =
         "proposer = EXCLUDED.proposer, expiration_time = EXCLUDED.expiration_time,"
         " review_period_time = EXCLUDED.review_period_time,"
         " proposed_transaction = EXCLUDED.proposed_transaction,"
         " required_active = EXCLUDED.required_active,"
         " available_active = EXCLUDED.available_active,"
         " required_owner = EXCLUDED.required_owner,"
         " available_owner = EXCLUDED.available_owner,"
         " available_keys = EXCLUDED.available_keys,"
         " fail_reason = EXCLUDED.fail_reason,"
         " last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }
   { // data rooms (1.23)
      projection_def d;
      d.space = 1; d.type = 23;
      d.table = "pgx.data_rooms";
      d.columns = "id, owner, name, description, subject_which, subject_instance,"
                  " encrypted, current_epoch, created, last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", " + inst("s->>'owner'") + ", s->>'name',"
         " s->>'description', (s->'subject'->>0)::smallint,"
         " CASE WHEN (s->'subject'->>0)::int = 0 THEN 0"
         "      ELSE " + inst("s->'subject'->>1") + " END,"
         " (s->>'encrypted')::boolean, (s->>'current_epoch')::int,"
         " (s->>'created')::timestamptz, blk";
      d.update_set =
         "owner = EXCLUDED.owner, name = EXCLUDED.name,"
         " description = EXCLUDED.description, subject_which = EXCLUDED.subject_which,"
         " subject_instance = EXCLUDED.subject_instance, encrypted = EXCLUDED.encrypted,"
         " current_epoch = EXCLUDED.current_epoch, created = EXCLUDED.created,"
         " last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }
   { // data room members (1.24)
      projection_def d;
      d.space = 1; d.type = 24;
      d.table = "pgx.data_room_members";
      d.columns = "id, room, member_which, member_account, member_key_pub, member_room,"
                  " member_key, permissions, added, last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", " + inst("s->>'room'") + ", "
         + member_which("member") + ", " + member_account("member") + ", "
         + member_key_pub("member") + ", " + member_room("member") + ","
         " s->>'member_key', (s->>'permissions')::int, (s->>'added')::timestamptz, blk";
      d.update_set =
         "room = EXCLUDED.room, member_which = EXCLUDED.member_which,"
         " member_account = EXCLUDED.member_account, member_key_pub = EXCLUDED.member_key_pub,"
         " member_room = EXCLUDED.member_room,"
         " member_key = EXCLUDED.member_key, permissions = EXCLUDED.permissions,"
         " added = EXCLUDED.added, last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }
   { // data room key epochs (1.25)
      projection_def d;
      d.space = 1; d.type = 25;
      d.table = "pgx.data_room_key_epochs";
      d.columns = "id, room, epoch, member_which, member_account, member_key_pub,"
                  " member_room, key, last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", " + inst("s->>'room'") + ", (s->>'epoch')::int, "
         + member_which("member") + ", " + member_account("member") + ", "
         + member_key_pub("member") + ", " + member_room("member") + ", s->>'key', blk";
      d.update_set =
         "room = EXCLUDED.room, epoch = EXCLUDED.epoch,"
         " member_which = EXCLUDED.member_which, member_account = EXCLUDED.member_account,"
         " member_key_pub = EXCLUDED.member_key_pub, member_room = EXCLUDED.member_room,"
         " key = EXCLUDED.key, last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }
   { // content cards (1.26)
      projection_def d;
      d.space = 1; d.type = 26;
      d.table = "pgx.content_cards";
      d.columns = "id, author_which, author_account, author_key_pub, room, hash, url, type,"
                  " description, content_key, storage_data, key_epoch, created, updated,"
                  " last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", "
         + member_which("author") + ", " + member_account("author") + ", "
         + member_key_pub("author") + ", " + inst("s->>'room'") + ","
         " s->>'hash', s->>'url', s->>'type', s->>'description', s->>'content_key',"
         " s->>'storage_data', (s->>'key_epoch')::int, (s->>'created')::timestamptz,"
         " (s->>'updated')::timestamptz, blk";
      d.update_set =
         "author_which = EXCLUDED.author_which, author_account = EXCLUDED.author_account,"
         " author_key_pub = EXCLUDED.author_key_pub,"
         " room = EXCLUDED.room, hash = EXCLUDED.hash,"
         " url = EXCLUDED.url, type = EXCLUDED.type, description = EXCLUDED.description,"
         " content_key = EXCLUDED.content_key, storage_data = EXCLUDED.storage_data,"
         " key_epoch = EXCLUDED.key_epoch, created = EXCLUDED.created,"
         " updated = EXCLUDED.updated, last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }

   { // content card grants (1.28)
      projection_def d;
      d.space = 1; d.type = 28;
      d.table = "pgx.content_card_grants";
      d.columns = "id, card, grantee_which, grantee_account, grantee_key_pub, key,"
                  " granted_by, created, last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", " + inst("s->>'card'") + ", "
         + member_which("grantee") + ", " + member_account("grantee") + ", "
         + member_key_pub("grantee") + ","
         " s->>'key', " + inst("s->>'granted_by'") + ", (s->>'created')::timestamptz, blk";
      d.update_set =
         "card = EXCLUDED.card, grantee_which = EXCLUDED.grantee_which,"
         " grantee_account = EXCLUDED.grantee_account,"
         " grantee_key_pub = EXCLUDED.grantee_key_pub, key = EXCLUDED.key,"
         " granted_by = EXCLUDED.granted_by, created = EXCLUDED.created,"
         " last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }

   { // content card links (1.29)
      projection_def d;
      d.space = 1; d.type = 29;
      d.table = "pgx.content_card_links";
      d.columns = "id, card, room, linker_which, linker_account, linker_key_pub,"
                  " link_key, link_epoch, card_epoch, created, last_updated_block";
      d.select_list =
         inst("s->>'id'") + ", " + inst("s->>'card'") + ", " + inst("s->>'room'") + ", "
         + member_which("linker") + ", " + member_account("linker") + ", "
         + member_key_pub("linker") + ","
         " s->>'link_key', (s->>'link_epoch')::int, (s->>'card_epoch')::int,"
         " (s->>'created')::timestamptz, blk";
      d.update_set =
         "card = EXCLUDED.card, room = EXCLUDED.room,"
         " linker_which = EXCLUDED.linker_which, linker_account = EXCLUDED.linker_account,"
         " linker_key_pub = EXCLUDED.linker_key_pub, link_key = EXCLUDED.link_key,"
         " link_epoch = EXCLUDED.link_epoch, card_epoch = EXCLUDED.card_epoch,"
         " created = EXCLUDED.created, last_updated_block = EXCLUDED.last_updated_block";
      defs.push_back( d );
   }

   return defs;
}

} // anonymous namespace

const std::vector<projection_def>& all_projections()
{
   static const std::vector<projection_def> defs = build_projections();
   return defs;
}

const projection_def* find_projection( uint8_t space, uint8_t type )
{
   for( const auto& d : all_projections() )
      if( d.space == space && d.type == type )
         return &d;
   return nullptr;
}

std::string projection_upsert_sql( const projection_def& d )
{
   return "INSERT INTO " + d.table + " (" + d.columns + ")"
          " SELECT " + d.select_list +
          " FROM (SELECT $1::jsonb AS s, $2::bigint AS blk) x" + d.joins +
          " ON CONFLICT (id) DO UPDATE SET " + d.update_set;
}

std::string projection_delete_sql( const projection_def& d )
{
   return "DELETE FROM " + d.table + " WHERE id = $1";
}

std::string projection_rebuild_sql( const projection_def& d )
{
   // `affected_objects` is a temp table (object_space, object_type, object_instance)
   // created by the reorg rollback. Delete the affected rows, then re-insert those
   // that still have a live current version in object_history - using exactly the
   // same extraction expressions as the live upsert path.
   const std::string space_str = std::to_string( d.space );
   const std::string type_str = std::to_string( d.type );
   return "DELETE FROM " + d.table + " t USING affected_objects a"
          " WHERE a.object_space = " + space_str + " AND a.object_type = " + type_str +
          "   AND t.id = a.object_instance;"
          " INSERT INTO " + d.table + " (" + d.columns + ")"
          " SELECT " + d.select_list +
          " FROM (SELECT h.state AS s, h.valid_from_block AS blk"
          "       FROM pgx.object_history h"
          "       JOIN affected_objects a ON a.object_space = h.object_space"
          "        AND a.object_type = h.object_type"
          "        AND a.object_instance = h.object_instance"
          "       WHERE h.object_space = " + space_str +
          "         AND h.object_type = " + type_str +
          "         AND h.valid_to_block IS NULL AND h.change_kind <> 'r') x" + d.joins;
}

std::string market_trade_insert_sql()
{
   return
      "INSERT INTO pgx.market_trades (op_seq, block_num, block_time, account,"
      " order_type, order_instance, pays_asset, pays_amount, receives_asset,"
      " receives_amount, fill_price_base_amount, fill_price_base_asset,"
      " fill_price_quote_amount, fill_price_quote_asset, price, is_maker)"
      " SELECT $1::bigint, $2::bigint, $3::timestamptz,"
      " split_part(o->>'account_id', '.', 3)::bigint,"
      " split_part(o->>'order_id', '.', 2)::smallint,"
      " split_part(o->>'order_id', '.', 3)::bigint,"
      " split_part(o->'pays'->>'asset_id', '.', 3)::bigint,"
      " (o->'pays'->>'amount')::bigint,"
      " split_part(o->'receives'->>'asset_id', '.', 3)::bigint,"
      " (o->'receives'->>'amount')::bigint,"
      " (o->'fill_price'->'base'->>'amount')::bigint,"
      " split_part(o->'fill_price'->'base'->>'asset_id', '.', 3)::bigint,"
      " (o->'fill_price'->'quote'->>'amount')::bigint,"
      " split_part(o->'fill_price'->'quote'->>'asset_id', '.', 3)::bigint,"
      " ((o->'receives'->>'amount')::numeric * power(10::numeric, pays_a.precision))"
      "  / NULLIF((o->'pays'->>'amount')::numeric"
      "           * power(10::numeric, recv_a.precision), 0),"
      " (o->>'is_maker')::boolean"
      " FROM (SELECT $4::jsonb AS o) x"
      " LEFT JOIN pgx.assets pays_a"
      "   ON pays_a.id = split_part(o->'pays'->>'asset_id', '.', 3)::bigint"
      " LEFT JOIN pgx.assets recv_a"
      "   ON recv_a.id = split_part(o->'receives'->>'asset_id', '.', 3)::bigint";
}

} } // graphene::pg_indexer
