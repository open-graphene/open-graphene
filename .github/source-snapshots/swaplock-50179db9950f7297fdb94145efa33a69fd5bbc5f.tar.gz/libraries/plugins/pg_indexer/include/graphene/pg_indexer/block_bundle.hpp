/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once

#include <fc/variant.hpp>
#include <fc/time.hpp>
#include <fc/container/flat.hpp>

#include <string>
#include <vector>

namespace graphene { namespace pg_indexer {

/// One transaction of a block (raw layer)
struct tx_entry
{
   std::string trx_id;
   uint16_t    ref_block_num = 0;
   uint32_t    ref_block_prefix = 0;
   fc::time_point_sec expiration;
   uint32_t    operation_count = 0;
   fc::variant signatures_v;
};

/// One (possibly virtual) operation of a block (raw layer)
struct op_entry
{
   int32_t  trx_in_block = 0;
   int32_t  op_in_trx = 0;
   int32_t  virtual_op = 0;
   bool     is_virtual = false;
   int16_t  op_type = 0;
   uint64_t fee_payer_instance = 0;
   fc::variant op_v;      ///< operation serialized to variant on the main thread
   fc::variant result_v;  ///< operation_result serialized to variant on the main thread
   fc::flat_set<uint64_t> impacted_accounts; ///< 1.2.x instances
};

/// One object delta of a block (temporal layer)
struct delta_entry
{
   uint8_t  space = 0;
   uint8_t  type = 0;
   uint64_t instance = 0;
   char     kind = 'u';   ///< 'c' create, 'u' update, 'r' remove
   fc::variant state_v;   ///< object state at delta time (null for 'r')
};

/// Everything the indexer captured for one applied block. Assembled on the main
/// thread while the block is being applied; consumed by the writer thread.
struct block_bundle
{
   uint32_t    block_num = 0;
   std::string block_id;
   std::string previous;
   fc::time_point_sec timestamp;
   uint64_t    witness_instance = 0;
   std::string witness_signature;

   std::vector<tx_entry>    txs;
   std::vector<op_entry>    ops;
   std::vector<delta_entry> deltas;

   /// When != 0 the writer must first roll back all indexed data with
   /// block_num >= rollback_from (chain reorganization), then apply this bundle.
   uint32_t rollback_from = 0;

   /// Startup state reconciliation: `deltas` carries a full snapshot ('s') of all
   /// live tracked objects at block_num; the writer diffs it against object_history
   /// current rows (upserting changes, closing rows for vanished objects) instead
   /// of applying it as a regular block.
   bool reconcile = false;
};

} } // graphene::pg_indexer
