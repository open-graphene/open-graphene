/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once

#include <graphene/pg_indexer/block_bundle.hpp>
#include <graphene/pg_indexer/pg_client.hpp>

#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>

namespace graphene { namespace pg_indexer {

struct writer_options
{
   std::string connection_url = "postgresql://localhost/swaplock";
   uint32_t bulk_replay = 1000;    ///< max blocks per SQL transaction during replay
   uint32_t bulk_sync = 1;         ///< max blocks per SQL transaction when synced
   uint32_t queue_capacity = 4096; ///< bundles buffered before backpressure
   bool     fail_fast = true;      ///< on-error=exit: give up after retry window
   uint32_t retry_seconds = 30;    ///< how long to retry a failing batch before giving up
};

/// Dedicated thread that drains block bundles into PostgreSQL.
/// All libpq I/O happens here; the main thread only enqueues.
class pg_writer
{
   public:
      explicit pg_writer( writer_options options );
      ~pg_writer();

      /// Connects, creates/migrates the schema, loads indexer_state.
      /// Called on the main thread before start() (any error aborts plugin init).
      void initialize();
      void start();
      /// Drains the queue, then stops the thread.
      void stop();

      /// Blocks when the queue is full (backpressure); throws if the writer is dead.
      void enqueue( block_bundle&& bundle );

      /// True after an unrecoverable write error (fail_fast); the plugin turns
      /// this into an exception on the next applied_block.
      bool fatal()const { return _fatal.load(); }

      uint32_t    last_indexed_block()const { return _last_block; }
      std::string last_indexed_block_id()const { return _last_block_id; }
      bool        object_history_empty()const { return _object_history_empty; }

   private:
      void run();
      void write_batch( std::deque<block_bundle>& batch );
      void write_bundle( const block_bundle& bundle );
      void write_delta( const delta_entry& delta, const std::string& block_num_str,
                        const std::string& block_time_str );
      void apply_projection( const delta_entry& delta, const std::string& block_num_str );
      void apply_reconcile( const block_bundle& bundle );
      /// Removes all indexed data with block_num >= block_num (chain reorg)
      void rollback_to( uint32_t block_num );
      /// Per-account next-sequence cache (lazily seeded from PostgreSQL)
      uint64_t& account_sequence( uint64_t account_instance );

      std::unordered_map<uint64_t, uint64_t> _acct_seq;

      writer_options _options;
      pg_client      _db;

      std::deque<block_bundle> _queue;
      std::mutex               _mutex;
      std::condition_variable  _cv_push;
      std::condition_variable  _cv_pop;
      std::thread              _thread;
      std::atomic<bool>        _shutdown{ false };
      std::atomic<bool>        _fatal{ false };

      // bookkeeping mirrored from pgx.indexer_state (writer thread only after start;
      // main thread reads last_* before start for skip/reorg decisions)
      uint32_t    _last_block = 0;
      std::string _last_block_id;
      uint64_t    _next_op_seq = 1;
      bool        _object_history_empty = true;
};

} } // graphene::pg_indexer
