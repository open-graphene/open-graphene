/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace graphene { namespace pg_indexer {

/**
 * A typed projection: how one object type maps from its jsonb state onto a typed
 * current-state table. The jsonb -> column extraction lives in `select_list`
 * (SQL over the alias `s` = state jsonb, `blk` = block number), so the same
 * expressions serve both the live upsert path and the rebuild-from-object_history
 * path used after chain reorganizations.
 */
struct projection_def
{
   uint8_t     space = 0;
   uint8_t     type = 0;
   std::string table;           ///< e.g. "pgx.accounts"
   std::string columns;         ///< target column list, first column is the id
   std::string select_list;     ///< expressions over s / blk, aligned with columns
   std::string joins;           ///< extra JOIN clauses (may reference x), optional
   std::string update_set;      ///< ON CONFLICT (id) DO UPDATE SET ...
};

/// All typed projections, keyed by (space, type)
const std::vector<projection_def>& all_projections();

/// Find a projection for the object type, or nullptr
const projection_def* find_projection( uint8_t space, uint8_t type );

/// INSERT ... SELECT <select_list> FROM (SELECT $1::jsonb s, $2::bigint blk) x
/// <joins> ON CONFLICT (id) DO UPDATE ...
std::string projection_upsert_sql( const projection_def& projection );

/// DELETE FROM <table> WHERE id = $1
std::string projection_delete_sql( const projection_def& projection );

/// Rebuild rows for the affected instances (temp table `affected_objects`) from
/// the current rows of pgx.object_history: first deletes the affected ids, then
/// re-inserts from history. Used by reorg rollback.
std::string projection_rebuild_sql( const projection_def& projection );

/// INSERT into pgx.market_trades from a fill_order operation
/// ($1 op_seq, $2 block_num, $3 block_time, $4 op jsonb)
std::string market_trade_insert_sql();

} } // graphene::pg_indexer
