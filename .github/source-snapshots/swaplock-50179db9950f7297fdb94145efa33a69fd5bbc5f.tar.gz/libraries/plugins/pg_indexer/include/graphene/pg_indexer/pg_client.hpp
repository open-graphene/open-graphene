/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once

#include <memory>
#include <string>
#include <vector>

// forward declarations to keep libpq out of dependent headers
struct pg_conn;
struct pg_result;

namespace graphene { namespace pg_indexer {

/// Minimal RAII holder for a libpq result
class pg_result_holder
{
   public:
      explicit pg_result_holder( pg_result* res ) : _res(res) {}
      ~pg_result_holder();
      pg_result_holder( pg_result_holder&& other ) noexcept : _res(other._res) { other._res = nullptr; }
      pg_result_holder( const pg_result_holder& ) = delete;
      pg_result_holder& operator=( const pg_result_holder& ) = delete;

      int  rows()const;
      int  columns()const;
      bool is_null( int row, int col )const;
      std::string value( int row, int col )const;

   private:
      pg_result* _res;
};

/// Minimal synchronous PostgreSQL client on top of libpq.
/// Used exclusively from the writer thread (single-threaded access).
class pg_client
{
   public:
      explicit pg_client( std::string conninfo );
      ~pg_client();
      pg_client( const pg_client& ) = delete;
      pg_client& operator=( const pg_client& ) = delete;

      void connect();      ///< (re)connects; throws fc::exception on failure
      void disconnect();
      bool connected()const;

      /// Execute a command (no result rows expected); throws on error
      void exec( const std::string& sql );
      /// Execute a query and return the result; throws on error
      pg_result_holder query( const std::string& sql );
      /// Execute a parameterized statement ($1..$n, all params as text;
      /// null entries expressed via the parallel `nulls` vector); throws on error
      void exec_params( const std::string& sql, const std::vector<std::string>& params,
                        const std::vector<bool>* nulls = nullptr );

      void begin();
      void commit();
      void rollback() noexcept; ///< best effort, never throws

      /// SQL string literal (with quotes), safe for direct interpolation
      std::string literal( const std::string& text );

   private:
      void check_connection();

      std::string _conninfo;
      pg_conn*    _conn = nullptr;
};

} } // graphene::pg_indexer
