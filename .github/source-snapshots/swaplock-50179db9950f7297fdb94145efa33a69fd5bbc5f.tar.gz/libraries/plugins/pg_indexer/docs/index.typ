// pg_indexer — dokumentacja pluginu
// Kompilacja: typst compile index.typ

#set document(
  title: "pg_indexer — indekser PostgreSQL dla swaplock-core",
  author: "SwapLock",
)
#set page(margin: (x: 2.2cm, y: 2.4cm), numbering: "1 / 1")
#set text(font: "Helvetica Neue", size: 10.5pt, lang: "pl")
#set heading(numbering: "1.1")
#show heading: it => block(above: 1.4em, below: 0.8em, it)
#show raw.where(block: true): it => block(
  width: 100%,
  fill: luma(248),
  stroke: luma(220),
  inset: 8pt,
  radius: 3pt,
  text(size: 9pt, it),
)
#show table: set text(size: 9pt)

#align(center)[
  #text(size: 20pt, weight: "bold")[pg_indexer]
  #v(0.2em)
  #text(size: 13pt)[Indekser PostgreSQL dla swaplock-core]
  #v(0.4em)
  #text(size: 9pt, fill: luma(100))[
    Plugin `witness_node` · schema `pgx` · zastępuje pluginy `elasticsearch` / `es_objects`
  ]
]
#v(1.5em)

= Przegląd

`pg_indexer` strumieniuje pełną zawartość łańcucha do bazy PostgreSQL w trzech
warstwach:

+ *warstwa surowa* — bloki, transakcje i wszystkie operacje (łącznie z
  wirtualnymi, np. fill_order) z pełnym payloadem w JSONB,
+ *warstwa temporalna* — historia wersji (SCD2) *wszystkich* obiektów łańcucha:
  „time travel" i pełny audyt każdej zmiany,
+ *projekcje typowane* — bieżący stan w klasycznych, relacyjnych tabelach:
  konta, assety, balanse, zlecenia, transakcje rynkowe oraz cała domena
  SwapLock (data roomy, członkowie, epoki kluczy, content cards z full-text
  search).

W odróżnieniu od indeksowania do Elasticsearcha plugin:

- *poprawnie obsługuje reorganizacje łańcucha* — rollback jest jedną transakcją
  SQL, więc w bazie nigdy nie ma danych z osieroconych bloków (plugin ES
  zostawiał je na zawsze),
- nie spłaszcza dokumentów (JSONB nie ma limitów zagnieżdżenia mappingu),
- daje relacyjne złączenia, dokładną arytmetykę `numeric` dla cen oraz
  wbudowany full-text search.

Plugin jest czysto addytywny: nie dotyka stanu łańcucha, nie wystawia RPC
i koegzystuje z pluginem `account_history` (portfel działa bez zmian).

= Architektura

#figure(
  align(center, box(inset: 6pt)[
    #set text(size: 9pt)
    #let cell(title, body, fill: luma(245)) = box(
      width: 100%, fill: fill, stroke: luma(180), radius: 4pt, inset: 7pt,
    )[#align(center)[*#title* \ #text(size: 8pt)[#body]]]
    #grid(
      columns: (1fr, auto, 1fr, auto, 1fr),
      column-gutter: 6pt, row-gutter: 6pt, align: horizon,
      cell("wątek główny (th_a)")[
        sygnały: `applied_block`, \ `new/changed/removed_objects` \
        → budowa *block_bundle* \ (serializacja do `fc::variant`)
      ],
      [→],
      cell("kolejka ograniczona")[
        bundle per blok \ backpressure: pełna kolejka \ wstrzymuje aplikowanie bloków
      ],
      [→],
      cell("wątek writera (libpq)")[
        batch = 1 transakcja SQL \ (replay: do 1000 bloków) \
        detekcja reorg → rollback \ retry + polityka błędów
      ],
    )
  ]),
  caption: [Przepływ danych: cała komunikacja z PostgreSQL odbywa się poza
    wątkiem aplikowania bloków.],
)

Kluczowe decyzje:

- *Bundle domykany po wszystkich sygnałach bloku.* Sygnały delt obiektów
  odpalają się synchronicznie po `applied_block` w tym samym `_apply_block`;
  zadanie `fc::async` zaplanowane w handlerze `applied_block` wykonuje się po
  nich wszystkich i wtedy bundle trafia do kolejki.
- *Rozróżnienie replay vs reorg po stronie writera.* Blok o wysokości już
  zindeksowanej z *tym samym* `block_id` to replay (pomijany); z *innym* —
  reorganizacja (rollback). Dzięki temu `--replay-blockchain` jest bezpieczny
  i idempotentny.
- *`op_seq` jest licznikiem pluginu* (utrwalanym w `pgx.indexer_state`), a nie
  id z `operation_history_object` — te zależą od konfiguracji innych pluginów
  historii i ich pruningu.

= Uruchomienie

```bash
createdb swaplock
witness_node \
  --plugins "witness account_history api_helper_indexes pg_indexer" \
  --pg-indexer-connection-url postgresql://localhost/swaplock

psql swaplock -c "select * from pgx.v_order_book"
```

Schema `pgx` jest tworzona i migrowana automatycznie przy starcie
(wersjonowanie w `pgx.schema_migrations`, advisory lock chroni przed
równoległymi migracjami).

== Opcje

#table(
  columns: (auto, auto, 1fr),
  stroke: luma(200),
  table.header([*Opcja* (prefiks `pg-indexer-`)], [*Domyślnie*], [*Znaczenie*]),
  [`connection-url`], [`postgresql://localhost/swaplock`], [URI/conninfo libpq],
  [`bulk-replay`], [1000], [bloków na transakcję SQL podczas replayu],
  [`bulk-sync`], [1], [bloków na transakcję przy synchronizacji z headem (< 30 s od head)],
  [`queue-capacity`], [4096], [pojemność kolejki; po zapełnieniu backpressure wstrzymuje aplikowanie bloków],
  [`start-block`], [0], [pomiń wiersze warstwy surowej poniżej tego bloku],
  [`irreversible-only`], [false], [zapisuj wyłącznie bloki nieodwracalne (@irrev)],
  [`object-types-exclude`], [`2.1,2.8,2.9,1.11,2.7`], [typy `space.type` wyłączone z historii temporalnej],
  [`sync-state-on-startup`], [false], [wymuś rekoncyliację stanu przy starcie],
  [`on-error`], [`exit`], [`exit`: węzeł zatrzymuje się, gdy PostgreSQL trwale zawodzi; `retry`: ponawiaj bez końca],
  [`retry-seconds`], [30], [okno ponowień przed zastosowaniem `on-error`],
)

= Schemat bazy (schema `pgx`)

Konwencje:

- identyfikatory obiektów przechowywane jako *`bigint` numer instancji* tam,
  gdzie przestrzeń/typ wynika z semantyki kolumny (`fee_payer` = 1.2.x,
  `asset_id` = 1.3.x, …); pełna trójka `(object_space, object_type,
  object_instance)` + generowany tekstowy `object_id` tylko w `object_history`,
- kwoty jako `bigint` (satoshi; `share_type` = int64), *ceny jako `numeric`*
  liczone z surowych kwot i precyzji assetów — nigdy zmiennoprzecinkowo,
- czasy jako `timestamptz` (UTC),
- brak kluczy obcych na tabelach surowych (przepustowość; integralność
  gwarantuje łańcuch).

== Warstwa 1 — surowa

#table(
  columns: (auto, 1fr),
  stroke: luma(200),
  table.header([*Tabela*], [*Zawartość*]),
  [`blocks`], [`block_num` (PK), `block_id`, `previous`, `timestamp`, `witness`, `tx_count`, `witness_signature`],
  [`transactions`], [PK `(block_num, trx_in_block)`, `trx_id`, `ref_*`, `expiration`, `operation_count`, `signatures jsonb`],
  [`operations`], [`op_seq` (PK), pozycja `(block_num, trx_in_block, op_in_trx, virtual_op)`, `op_type` (0–87), `is_virtual`, `fee_payer`, `block_time`, `op jsonb` (+ indeks GIN), `result jsonb`],
  [`account_operations`], [PK `(account_id, sequence)` — historia per konto z ciągłą sekwencją od 1 (odpowiednik `account_history`); `op_seq`, `block_num`],
)

== Warstwa 2 — temporalna (SCD2)

`object_history(object_space, object_type, object_instance, object_id,
state jsonb, change_kind, valid_from_block, valid_to_block, block_time)`

Każda wersja każdego śledzonego obiektu to wiersz; wersja bieżąca ma
`valid_to_block IS NULL` (widok `pgx.v_objects_current`). `change_kind`:
`c`reate / `u`pdate / `r`emove (state NULL — ostatni stan niesie poprzedni
wiersz) / `s`napshot (rekoncyliacja startowa).

== Warstwa 3 — projekcje typowane

#table(
  columns: (auto, 1fr),
  stroke: luma(200),
  table.header([*Tabela*], [*Uwagi*]),
  [`accounts`], [`id`, `name`, `registrar`, `referrer`, `owner_auth/active_auth jsonb`, `memo_key`],
  [`assets`], [`id`, `symbol`, `issuer`, `precision`, `max_supply`, `is_bitasset`, `options jsonb`],
  [`balances`], [`(account_id, asset_id) → amount`],
  [`limit_orders`], [aktualna książka; `price numeric` = jednostki otrzymywane za 1 jednostkę sprzedawaną],
  [`data_rooms`], [`subject_which` (0 = brak, 1 = asset, 2 = konto) + `subject_instance`; `room_key IS NULL` = room jawny],
  [`data_room_members`], [bitmaska `permissions`: 0x01 update_room … 0x40 rotate_keys],
  [`data_room_key_epochs`], [klucz epoki per (room, epoch, konto)],
  [`content_cards`], [pełne pola karty + generowana kolumna `search tsvector` (description, type, url) z indeksem GIN],
  [`market_trades`], [wiersz per operacja fill_order — strona makera *i* takera; `is_maker` filtruje do jednego wiersza na fill ekonomiczny; dokładna cena `numeric`],
)

Widoki: `v_order_book` (posortowana książka z ilościami w jednostkach),
`v_ohlcv_1m` (świece minutowe per rynek — szablon dla grubszych interwałów),
`v_objects_current`.

= Semantyka

== Reorganizacje (tryb domyślny, realtime)

Bloki indeksowane są na bieżąco, na czubku łańcucha. Wykrycie forka (nowy blok
na zindeksowanej wysokości z innym id albo następnik z niepasującym
`previous`) uruchamia w *jednej transakcji SQL*: usunięcie wierszy surowych
`block_num >= punkt_forka`, usunięcie/ponowne otwarcie wersji w
`object_history` oraz odbudowę dotkniętych wierszy projekcji z historii — tą
samą ekstrakcją `jsonb → kolumny`, której używa ścieżka bieżąca, więc obie nie
mogą się rozjechać. Mechanizm samoczynnie leczy również przypadek „węzeł ubity
zanim utrwalił swój head block" po restarcie.

== Tryb `irreversible-only` <irrev>

Bundle są buforowane w pamięci i trafiają do PostgreSQL dopiero, gdy obejmie
je `last_irreversible_block_num` (przy 3 witnessach ≈ 2 bloki opóźnienia).
Baza nigdy nie cofa się wstecz. Po nieczystym zamknięciu węzła uruchom go z
`--replay-blockchain`, żeby uzupełnić lukę między ostatnim zapisanym blokiem
a head.

== Replay i pierwszy start

- Warstwa surowa replayuje się w całości (`applied_block` odpala się dla
  każdego bloku; już zindeksowane bloki są pomijane po porównaniu id).
- Sygnały delt obiektów emitowane są tylko dla ostatnich 10 000 bloków replayu
  (okno undo-history). Dlatego przy starcie plugin wykonuje *rekoncyliację*:
  przy pustej bazie robi snapshot wszystkich żywych obiektów
  (`change_kind = 's'`); w przeciwnym razie (lub z `sync-state-on-startup`)
  porównuje żywe obiekty z wierszami bieżącymi i aktualizuje tylko różnice.
  Konsekwencja: zakres replayowany bez delt ma w historii temporalnej
  granulację snapshotu, nie per blok. Pełna historia per blok od genesis =
  plugin włączony od genesis.

== Polityka błędów

Writer ponawia z backoffem (0,5 s → 8 s) przez `retry-seconds`; potem
`on-error = exit` zatrzymuje węzeł (indekser nigdy cicho nie rozjeżdża się
z łańcuchem — po restarcie wznawia dokładnie od `pgx.indexer_state`),
a `retry` ponawia w nieskończoność, aż backpressure wstrzyma aplikowanie
bloków.

= Przykładowe zapytania

Dowolne zapytanie po payloadzie operacji (indeks GIN):

```sql
SELECT block_num, op FROM pgx.operations
 WHERE op @> '{"to": "1.2.101"}';
```

Time travel — stan data roomu na zadanym bloku:

```sql
SELECT state FROM pgx.object_history
 WHERE object_id = '1.23.0'
   AND valid_from_block <= 5000
   AND (valid_to_block > 5000 OR valid_to_block IS NULL);
```

Audyt: kto i kiedy zmieniał kartę (compliance dla tokenizacji):

```sql
SELECT valid_from_block, block_time, change_kind,
       state->>'url' AS url, state->>'key_epoch' AS key_epoch
  FROM pgx.object_history
 WHERE object_id = '1.26.0'
 ORDER BY valid_from_block;
```

Full-text search po kartach:

```sql
SELECT c.hash, c.url, r.name AS room
  FROM pgx.content_cards c JOIN pgx.data_rooms r ON r.id = c.room
 WHERE c.search @@ websearch_to_tsquery('simple', 'certyfikat magazynowy');
```

Wszystkie data roomy assetu (subject 1 = asset):

```sql
SELECT r.* FROM pgx.data_rooms r
  JOIN pgx.assets a ON a.id = r.subject_instance
 WHERE r.subject_which = 1 AND a.symbol = 'GOLDX';
```

Order book i świece:

```sql
SELECT * FROM pgx.v_order_book
 WHERE sell_symbol = 'GOLDX' AND receive_symbol = 'BTS';

SELECT * FROM pgx.v_ohlcv_1m WHERE asset_a = 0 AND asset_b = 100
 ORDER BY bucket DESC LIMIT 60;
```

Historia operacji konta (paginacja jak w portfelu):

```sql
SELECT o.block_time, o.op_type, o.op
  FROM pgx.account_operations ao
  JOIN pgx.operations o USING (op_seq)
 WHERE ao.account_id = 100 AND ao.sequence BETWEEN 1 AND 100
 ORDER BY ao.sequence;
```

= Testy

#table(
  columns: (auto, 1fr),
  stroke: luma(200),
  table.header([*Test*], [*Zakres i uruchomienie*]),
  [`pg_test`], [testy na `database_fixture` (wymagają lokalnego PostgreSQL):
    warstwa surowa i sekwencje per konto, łańcuchy wersji SCD2, deterministyczny
    reorg przez `pop_block`. \
    `createdb swaplock_unittest && GRAPHENE_TESTING_PG_URL=postgresql://localhost/swaplock_unittest ./build-macos/tests/pg_test`],
  [`e2e_devnet.sh`], [`tests/pg_indexer/e2e_devnet.sh` — pełny scenariusz na
    jednowęzłowym łańcuchu dev (izolowane porty): asset, data room przypięty do
    assetu, członek typu bonded-warehouse (samo `create_content`), karty +
    full-text, krzyżujące się zlecenia; asercje księgi/OHLCV/balansów względem
    RPC węzła.],
)

= Uwagi operacyjne

- Wymagany `libpq` (macOS: `brew install libpq`; Linux: `libpq-dev`) — CMake
  znajduje go makrem `FIND_POSTGRESQL` w głównym `CMakeLists.txt`.
- Duża kompresja historii: `object-types-exclude` domyślnie pomija obiekty
  zmieniające się co blok (2.1) oraz księgowość pluginów historii (1.11, 2.7,
  2.8, 2.9), która dubluje warstwę surową.
- Kolejka pełna = celowe wstrzymanie aplikowania bloków (indekser nigdy nie
  gubi danych). Rozmiar reguluje `queue-capacity`.
- Długotrwałe testy/regresje na macOS uruchamiaj pod `caffeinate -i` —
  uśpienie systemu potrafi zakleszczyć timed-waity schedulera fc.
