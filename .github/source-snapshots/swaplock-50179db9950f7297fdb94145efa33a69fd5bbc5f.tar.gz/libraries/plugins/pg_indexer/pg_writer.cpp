/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <graphene/pg_indexer/pg_writer.hpp>
#include <graphene/pg_indexer/projections.hpp>
#include <graphene/pg_indexer/schema.hpp>

#include <fc/exception/exception.hpp>
#include <fc/io/json.hpp>
#include <fc/log/logger.hpp>
#include <fc/time.hpp>

#include <chrono>

namespace graphene { namespace pg_indexer {

pg_writer::pg_writer( writer_options options )
   : _options( std::move(options) ), _db( _options.connection_url )
{
}

pg_writer::~pg_writer()
{
   stop();
}

void pg_writer::initialize()
{
   _db.connect();
   ensure_schema( _db );

   auto state = _db.query( "SELECT last_block, last_block_id, next_op_seq"
                           " FROM pgx.indexer_state WHERE id = 1" );
   FC_ASSERT( state.rows() == 1, "pgx.indexer_state is missing its row" );
   _last_block = uint32_t( std::stoul( state.value( 0, 0 ) ) );
   _last_block_id = state.value( 0, 1 );
   _next_op_seq = std::stoull( state.value( 0, 2 ) );

   auto history_probe = _db.query( "SELECT 1 FROM pgx.object_history LIMIT 1" );
   _object_history_empty = ( history_probe.rows() == 0 );

   ilog( "pg_indexer: connected; last indexed block ${b}, next op_seq ${s}",
         ("b", _last_block)("s", _next_op_seq) );
}

void pg_writer::start()
{
   _shutdown.store( false );
   _thread = std::thread( [this]() { run(); } );
}

void pg_writer::stop()
{
   if( !_thread.joinable() )
      return;
   {
      std::unique_lock<std::mutex> lock( _mutex );
      _shutdown.store( true );
   }
   _cv_pop.notify_all();
   _cv_push.notify_all();
   _thread.join();
   _db.disconnect();
}

void pg_writer::enqueue( block_bundle&& bundle )
{
   std::unique_lock<std::mutex> lock( _mutex );
   _cv_push.wait( lock, [this]() {
      return _queue.size() < _options.queue_capacity || _fatal.load() || _shutdown.load();
   });
   FC_ASSERT( !_fatal.load(), "pg_indexer writer is in a fatal state" );
   if( _shutdown.load() )
      return; // shutting down; bundle dropped deliberately
   _queue.push_back( std::move(bundle) );
   lock.unlock();
   _cv_pop.notify_one();
}

void pg_writer::run()
{
   while( true )
   {
      std::deque<block_bundle> batch;
      {
         std::unique_lock<std::mutex> lock( _mutex );
         _cv_pop.wait( lock, [this]() { return !_queue.empty() || _shutdown.load(); } );
         if( _queue.empty() && _shutdown.load() )
            return;

         // Sync mode (head bundle is recent): small transactions for low latency.
         // Replay mode: large transactions for throughput.
         bool is_sync = ( fc::time_point::now() - _queue.front().timestamp ) < fc::seconds(30);
         size_t take = is_sync ? _options.bulk_sync : _options.bulk_replay;
         if( take < 1 ) take = 1;
         while( !_queue.empty() && batch.size() < take )
         {
            batch.push_back( std::move(_queue.front()) );
            _queue.pop_front();
         }
      }
      _cv_push.notify_all();

      // Write the batch; on failure retry with backoff for retry_seconds, then
      // either die (fail_fast) or keep retrying forever (backpressure pauses the node).
      auto give_up_at = std::chrono::steady_clock::now()
                        + std::chrono::seconds( _options.retry_seconds );
      int64_t backoff_ms = 500;
      while( true )
      {
         try
         {
            write_batch( batch );
            break;
         }
         catch( const std::exception& e )
         {
            wlog( "pg_indexer: batch write failed (std): ${e}", ("e", std::string(e.what())) );
            _db.rollback();
            if( _options.fail_fast && std::chrono::steady_clock::now() > give_up_at )
            {
               elog( "pg_indexer: giving up after ${s}s of retries; entering fatal state",
                     ("s", _options.retry_seconds) );
               _fatal.store( true );
               _cv_push.notify_all();
               return;
            }
            std::this_thread::sleep_for( std::chrono::milliseconds( backoff_ms ) );
            if( backoff_ms < 8000 )
               backoff_ms *= 2;
         }
         catch( const fc::exception& e )
         {
            wlog( "pg_indexer: batch write failed: ${e}", ("e", e.to_detail_string()) );
            _db.rollback();
            if( _options.fail_fast && std::chrono::steady_clock::now() > give_up_at )
            {
               elog( "pg_indexer: giving up after ${s}s of retries; entering fatal state",
                     ("s", _options.retry_seconds) );
               _fatal.store( true );
               _cv_push.notify_all();
               return;
            }
            std::this_thread::sleep_for( std::chrono::milliseconds( backoff_ms ) );
            if( backoff_ms < 8000 )
               backoff_ms *= 2;
            try
            {
               if( !_db.connected() )
                  _db.connect();
            }
            catch( const fc::exception& conn_error )
            {
               wlog( "pg_indexer: reconnect failed: ${e}", ("e", conn_error.to_string()) );
            }
         }
      }
   }
}

void pg_writer::write_batch( std::deque<block_bundle>& batch )
{
   if( batch.empty() )
      return;

   _db.begin();
   try
   {
      for( const auto& bundle : batch )
      {
         if( bundle.reconcile )
         {
            apply_reconcile( bundle );
            continue;
         }

         // Replay vs. reorg discrimination:
         // - a bundle at or below the last indexed block with the SAME block id as
         //   stored is a benign re-application (node replay over an indexed range)
         //   and is skipped;
         // - the same position with a DIFFERENT id, or a successor whose `previous`
         //   does not match our tip, is a chain reorganization.
         if( bundle.block_num <= _last_block )
         {
            auto stored = _db.query( "SELECT block_id FROM pgx.blocks WHERE block_num = "
                                     + std::to_string( bundle.block_num ) );
            if( stored.rows() == 1 && stored.value( 0, 0 ) == bundle.block_id )
               continue; // replay duplicate
            rollback_to( bundle.block_num );
         }
         else if( bundle.block_num == _last_block + 1 && _last_block != 0
                  && bundle.previous != _last_block_id )
         {
            rollback_to( bundle.block_num );
         }
         else if( bundle.block_num > _last_block + 1 && _last_block != 0 )
         {
            wlog( "pg_indexer: gap in indexed blocks (${l} -> ${b}); "
                  "restart the node with --replay-blockchain to backfill",
                  ("l", _last_block)("b", bundle.block_num) );
         }

         try
         {
            write_bundle( bundle );
         }
         FC_CAPTURE_AND_RETHROW( (bundle.block_num) )
         _last_block = bundle.block_num;
         _last_block_id = bundle.block_id;
      }

      _db.exec_params(
         "UPDATE pgx.indexer_state SET last_block = $1, last_block_id = $2, next_op_seq = $3"
         " WHERE id = 1",
         { std::to_string( _last_block ), _last_block_id, std::to_string( _next_op_seq ) } );
      _db.commit();
   }
   catch( ... )
   {
      _db.rollback();
      throw;
   }
}

void pg_writer::rollback_to( uint32_t block_num )
{
   // Removes everything derived from blocks >= block_num. Runs inside the current
   // batch transaction, so the rollback and the new-branch blocks land atomically.
   // Covers both true chain reorganizations and the restart-after-kill case where
   // the previous head block was indexed but never persisted by the node.
   wlog( "pg_indexer: rolling back indexed data from block ${b} (chain reorganization)",
         ("b", block_num) );
   const std::string cutoff = std::to_string( block_num );

   _db.exec( "DELETE FROM pgx.account_operations WHERE block_num >= " + cutoff );
   _db.exec( "DELETE FROM pgx.market_trades WHERE block_num >= " + cutoff );
   _db.exec( "DELETE FROM pgx.operations WHERE block_num >= " + cutoff );
   _db.exec( "DELETE FROM pgx.transactions WHERE block_num >= " + cutoff );
   _db.exec( "DELETE FROM pgx.blocks WHERE block_num >= " + cutoff );

   // temporal repair: drop versions created at/after the cutoff, reopen versions
   // they had superseded; remember which objects were touched
   _db.exec( "DROP TABLE IF EXISTS affected_objects" );
   _db.exec( "CREATE TEMP TABLE affected_objects ON COMMIT DROP AS"
             " SELECT DISTINCT object_space, object_type, object_instance"
             " FROM pgx.object_history"
             " WHERE valid_from_block >= " + cutoff +
             "    OR valid_to_block >= " + cutoff );
   _db.exec( "DELETE FROM pgx.object_history WHERE valid_from_block >= " + cutoff );
   _db.exec( "UPDATE pgx.object_history SET valid_to_block = NULL"
             " WHERE valid_to_block >= " + cutoff );

   // typed projections: rebuild every affected row from the (now-current) history
   // using the same jsonb extraction as the live upsert path
   for( const auto& projection : all_projections() )
      _db.exec( projection_rebuild_sql( projection ) );

   auto op_seq_result = _db.query( "SELECT coalesce(max(op_seq), 0) + 1 FROM pgx.operations" );
   _next_op_seq = std::stoull( op_seq_result.value( 0, 0 ) );
   _acct_seq.clear();

   if( block_num > 1 )
   {
      auto prev = _db.query( "SELECT block_id FROM pgx.blocks WHERE block_num = "
                             + std::to_string( block_num - 1 ) );
      _last_block = block_num - 1;
      _last_block_id = prev.rows() == 1 ? prev.value( 0, 0 ) : std::string();
   }
   else
   {
      _last_block = 0;
      _last_block_id.clear();
   }
}

uint64_t& pg_writer::account_sequence( uint64_t account_instance )
{
   auto itr = _acct_seq.find( account_instance );
   if( itr != _acct_seq.end() )
      return itr->second;
   auto result = _db.query( "SELECT coalesce(max(sequence), 0) FROM pgx.account_operations"
                            " WHERE account_id = " + std::to_string( account_instance ) );
   uint64_t seq = std::stoull( result.value( 0, 0 ) );
   return _acct_seq.emplace( account_instance, seq ).first->second;
}

void pg_writer::write_bundle( const block_bundle& bundle )
{
   const std::string block_num_str = std::to_string( bundle.block_num );
   const std::string block_time_str = bundle.timestamp.to_iso_string();

   _db.exec_params(
      "INSERT INTO pgx.blocks (block_num, block_id, previous, timestamp, witness,"
      " tx_count, witness_signature) VALUES ($1, $2, $3, $4, $5, $6, $7)",
      { block_num_str,
        bundle.block_id,
        bundle.previous,
        block_time_str,
        std::to_string( bundle.witness_instance ),
        std::to_string( bundle.txs.size() ),
        bundle.witness_signature } );

   for( size_t i = 0; i < bundle.txs.size(); ++i )
   {
      const auto& tx = bundle.txs[i];
      _db.exec_params(
         "INSERT INTO pgx.transactions (block_num, trx_in_block, trx_id, ref_block_num,"
         " ref_block_prefix, expiration, operation_count, signatures)"
         " VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb)",
         { block_num_str,
           std::to_string( i ),
           tx.trx_id,
           std::to_string( tx.ref_block_num ),
           std::to_string( tx.ref_block_prefix ),
           tx.expiration.to_iso_string(),
           std::to_string( tx.operation_count ),
           fc::json::to_string( tx.signatures_v ) } );
   }

   std::vector<std::pair<uint64_t, const op_entry*>> fill_ops;

   for( const auto& op : bundle.ops )
   {
      const uint64_t op_seq = _next_op_seq++;
      if( op.op_type == 4 ) // fill_order_operation
         fill_ops.emplace_back( op_seq, &op );
      _db.exec_params(
         "INSERT INTO pgx.operations (op_seq, block_num, trx_in_block, op_in_trx,"
         " virtual_op, is_virtual, op_type, fee_payer, block_time, op, result)"
         " VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10::jsonb, $11::jsonb)",
         { std::to_string( op_seq ),
           block_num_str,
           std::to_string( op.trx_in_block ),
           std::to_string( op.op_in_trx ),
           std::to_string( op.virtual_op ),
           op.is_virtual ? "true" : "false",
           std::to_string( op.op_type ),
           std::to_string( op.fee_payer_instance ),
           block_time_str,
           fc::json::to_string( op.op_v ),
           fc::json::to_string( op.result_v ) } );

      for( const auto& account : op.impacted_accounts )
      {
         uint64_t& sequence = account_sequence( account );
         ++sequence;
         _db.exec_params(
            "INSERT INTO pgx.account_operations (account_id, sequence, op_seq, block_num)"
            " VALUES ($1, $2, $3, $4)",
            { std::to_string( account ),
              std::to_string( sequence ),
              std::to_string( op_seq ),
              block_num_str } );
      }
   }

   for( const auto& delta : bundle.deltas )
      write_delta( delta, block_num_str, block_time_str );

   // Typed projections: reference data (accounts, assets) first, so price
   // computations for orders/trades created in the same block can join them
   auto is_reference_type = []( const delta_entry& delta ) {
      return delta.space == 1 && ( delta.type == 2 || delta.type == 3 );
   };
   for( const auto& delta : bundle.deltas )
      if( is_reference_type( delta ) )
         apply_projection( delta, block_num_str );
   for( const auto& delta : bundle.deltas )
      if( !is_reference_type( delta ) )
         apply_projection( delta, block_num_str );

   for( const auto& fill : fill_ops )
      _db.exec_params( market_trade_insert_sql(),
         { std::to_string( fill.first ),
           block_num_str,
           block_time_str,
           fc::json::to_string( fill.second->op_v ) } );
}

void pg_writer::apply_projection( const delta_entry& delta, const std::string& block_num_str )
{
   const auto* projection = find_projection( delta.space, delta.type );
   if( projection == nullptr )
      return;
   if( delta.kind == 'r' )
      _db.exec_params( projection_delete_sql( *projection ),
                       { std::to_string( delta.instance ) } );
   else
      _db.exec_params( projection_upsert_sql( *projection ),
                       { fc::json::to_string( delta.state_v ), block_num_str } );
}

void pg_writer::write_delta( const delta_entry& delta, const std::string& block_num_str,
                             const std::string& block_time_str )
{
   const std::string space_str = std::to_string( delta.space );
   const std::string type_str = std::to_string( delta.type );
   const std::string instance_str = std::to_string( delta.instance );

   // close the current version (the guard on valid_from_block keeps a same-block
   // create+update from closing the row it just inserted)
   _db.exec_params(
      "UPDATE pgx.object_history SET valid_to_block = $4"
      " WHERE object_space = $1 AND object_type = $2 AND object_instance = $3"
      "   AND valid_to_block IS NULL AND valid_from_block < $4",
      { space_str, type_str, instance_str, block_num_str } );

   const bool state_is_null = delta.kind == 'r';
   std::vector<std::string> params = {
      space_str, type_str, instance_str,
      state_is_null ? std::string() : fc::json::to_string( delta.state_v ),
      std::string( 1, delta.kind ),
      block_num_str, block_time_str };
   std::vector<bool> nulls = { false, false, false, state_is_null, false, false, false };
   _db.exec_params(
      "INSERT INTO pgx.object_history (object_space, object_type, object_instance,"
      " state, change_kind, valid_from_block, block_time)"
      " VALUES ($1, $2, $3, $4::jsonb, $5, $6, $7)"
      " ON CONFLICT (object_space, object_type, object_instance, valid_from_block)"
      " DO UPDATE SET state = EXCLUDED.state, change_kind = EXCLUDED.change_kind",
      params, &nulls );
}

void pg_writer::apply_reconcile( const block_bundle& bundle )
{
   const std::string block_num_str = std::to_string( bundle.block_num );
   const std::string block_time_str = bundle.timestamp.to_iso_string();

   _db.exec( "DROP TABLE IF EXISTS live_objects" );
   _db.exec( "CREATE TEMP TABLE live_objects ("
             " object_space smallint, object_type smallint, object_instance bigint,"
             " PRIMARY KEY (object_space, object_type, object_instance)"
             ") ON COMMIT DROP" );

   size_t updated = 0;
   for( const auto& delta : bundle.deltas )
   {
      const std::string space_str = std::to_string( delta.space );
      const std::string type_str = std::to_string( delta.type );
      const std::string instance_str = std::to_string( delta.instance );
      const std::string state_json = fc::json::to_string( delta.state_v );

      _db.exec_params( "INSERT INTO live_objects VALUES ($1, $2, $3)",
                       { space_str, type_str, instance_str } );

      // Upsert only when the live state differs from the current version
      // (jsonb comparison is semantic, so key order does not matter)
      auto current = _db.query(
         "SELECT (state = " + _db.literal( state_json ) + "::jsonb AND change_kind <> 'r')"
         " FROM pgx.object_history"
         " WHERE object_space = " + space_str + " AND object_type = " + type_str +
         "   AND object_instance = " + instance_str + " AND valid_to_block IS NULL" );
      if( current.rows() == 1 && current.value( 0, 0 ) == "t" )
         continue;

      write_delta( delta, block_num_str, block_time_str );
      apply_projection( delta, block_num_str );
      ++updated;
   }

   // Objects present in PostgreSQL as current but no longer alive on chain.
   // Only touch (space, type) pairs that the snapshot actually scanned.
   _db.exec( "DROP TABLE IF EXISTS stale_objects" );
   _db.exec( "CREATE TEMP TABLE stale_objects ON COMMIT DROP AS"
             " SELECT h.object_space, h.object_type, h.object_instance"
             " FROM pgx.object_history h"
             " WHERE h.valid_to_block IS NULL AND h.change_kind <> 'r'"
             "   AND EXISTS (SELECT 1 FROM live_objects l"
             "               WHERE l.object_space = h.object_space"
             "                 AND l.object_type = h.object_type)"
             "   AND NOT EXISTS (SELECT 1 FROM live_objects l"
             "                   WHERE l.object_space = h.object_space"
             "                     AND l.object_type = h.object_type"
             "                     AND l.object_instance = h.object_instance)" );
   _db.exec( "UPDATE pgx.object_history h SET valid_to_block = " + block_num_str +
             " FROM stale_objects s"
             " WHERE h.object_space = s.object_space AND h.object_type = s.object_type"
             "   AND h.object_instance = s.object_instance AND h.valid_to_block IS NULL" );
   _db.exec( "INSERT INTO pgx.object_history (object_space, object_type, object_instance,"
             " state, change_kind, valid_from_block, block_time)"
             " SELECT object_space, object_type, object_instance, NULL, 'r', "
             + block_num_str + ", '" + block_time_str + "' FROM stale_objects"
             " ON CONFLICT (object_space, object_type, object_instance, valid_from_block)"
             " DO UPDATE SET state = NULL, change_kind = 'r'" );
   for( const auto& projection : all_projections() )
      _db.exec( "DELETE FROM " + projection.table + " t USING stale_objects s"
                " WHERE s.object_space = " + std::to_string( projection.space ) +
                "   AND s.object_type = " + std::to_string( projection.type ) +
                "   AND t.id = s.object_instance" );

   ilog( "pg_indexer: reconciliation done at block ${b}: ${u} of ${n} objects updated",
         ("b", bundle.block_num)("u", updated)("n", bundle.deltas.size()) );
   _object_history_empty = false;
}

} } // graphene::pg_indexer
