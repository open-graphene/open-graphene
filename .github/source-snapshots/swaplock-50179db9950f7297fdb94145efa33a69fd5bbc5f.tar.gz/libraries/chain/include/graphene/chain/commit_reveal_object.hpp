/*
 * Copyright (c) 2020-2023 Revolution Populi Limited, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once

#include <graphene/chain/types.hpp>
#include <graphene/db/generic_index.hpp>

#include <boost/multi_index/composite_key.hpp>

namespace graphene { namespace chain {

/**
 * @brief Per-witness commit-reveal data used by the rdPOS randomness beacon
 * @ingroup object
 * @ingroup protocol
 *
 * Each witness commits a hash of a secret in the first half of a maintenance
 * interval and reveals the secret value in the second half. The sum of revealed
 * values seeds the PRNG used to randomly select the active witness set.
 */
class commit_reveal_object : public abstract_object<commit_reveal_object,
                                       protocol_ids, commit_reveal_object_type>
{
   public:
      account_id_type account;          ///< The witness account owning this commit-reveal slot
      string          hash;             ///< Committed hash of the secret
      uint64_t        value = 0;        ///< Revealed secret; 0 until revealed
      uint32_t        maintenance_time = 0; ///< Maintenance period the commit belongs to
};

struct by_account;

/**
* @ingroup object_index
*/
using commit_reveal_multi_index_type = multi_index_container<
   commit_reveal_object,
   indexed_by<
      ordered_unique< tag<by_id>, member< object, object_id_type, &object::id > >,
      ordered_unique< tag<by_account>,
         composite_key< commit_reveal_object,
            member< commit_reveal_object, account_id_type, &commit_reveal_object::account >
         >
      >
   >
>;

/**
* @ingroup object_index
*/
using commit_reveal_index = generic_index<commit_reveal_object, commit_reveal_multi_index_type>;

} } // graphene::chain

MAP_OBJECT_ID_TO_TYPE( graphene::chain::commit_reveal_object )

FC_REFLECT_TYPENAME( graphene::chain::commit_reveal_object )

GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::chain::commit_reveal_object )
