/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once

#include <graphene/chain/types.hpp>
#include <graphene/db/generic_index.hpp>
#include <graphene/protocol/data_room.hpp> // data_room_member_ref

#include <boost/multi_index/composite_key.hpp>

namespace graphene { namespace chain {

/**
 *  @brief A content card describes a document (or other content) stored off-chain,
 *         identified by its hash and belonging to a data room.
 *  @ingroup object
 *  @ingroup protocol
 */
class content_card_object : public abstract_object<content_card_object,
                                      protocol_ids, content_card_object_type>
{
   public:
      data_room_member_ref author;     ///< The member who created the card: an account or a key
      data_room_id_type room;          ///< The data room this card belongs to
      string            hash;          ///< Content hash (sha256 of the plaintext); not unique
      string            url;           ///< Content location
      string            type;          ///< Content type / MIME type
      string            description;   ///< Free-form description
      string            content_key;   ///< Content encryption key material; empty for public content
      string            storage_data;  ///< Storage metadata
      uint32_t          key_epoch = 0; ///< Room key epoch the content key belongs to
      time_point_sec    created;       ///< Creation time (head block time)
      time_point_sec    updated;       ///< Last update time (head block time)
};

struct by_room_hash; // for API lookup; non-unique - the hash is an integrity anchor, not an identity
struct by_room;      // for API and cascade removal (shared tag with data_room_object.hpp)
struct by_author;    // for API

/**
* @ingroup object_index
*/
using content_card_multi_index_type = multi_index_container<
   content_card_object,
   indexed_by<
      ordered_unique< tag<by_id>, member< object, object_id_type, &object::id > >,
      ordered_non_unique< tag<by_room_hash>,
         composite_key< content_card_object,
            member< content_card_object, data_room_id_type, &content_card_object::room >,
            member< content_card_object, string, &content_card_object::hash >
         >
      >,
      ordered_unique< tag<by_room>,
         composite_key< content_card_object,
            member< content_card_object, data_room_id_type, &content_card_object::room >,
            member< object, object_id_type, &object::id>
         >
      >,
      ordered_unique< tag<by_author>,
         composite_key< content_card_object,
            member< content_card_object, data_room_member_ref, &content_card_object::author >,
            member< object, object_id_type, &object::id>
         >
      >
   >
>;

/**
* @ingroup object_index
*/
using content_card_index = generic_index<content_card_object, content_card_multi_index_type>;


/**
 *  @brief One content card granted to one recipient, outside room membership.
 *  @ingroup object
 *  @ingroup protocol
 *
 *  The accountable form of disclosure: the card's content key encrypted to the grantee,
 *  with who granted it and when. Grants survive key rotation (a card's content key never
 *  changes) and are cascade-removed with their card, with a content change of their card,
 *  and with their room.
 */
class content_card_grant_object : public abstract_object<content_card_grant_object,
                                            protocol_ids, content_card_grant_object_type>
{
   public:
      content_card_id_type card;       ///< The granted card
      data_room_member_ref grantee;    ///< The recipient: an account or a public key
      string               key;        ///< The card's content key encrypted to the grantee
      account_id_type      granted_by; ///< The account that granted access
      time_point_sec       created;    ///< Grant time (head block time)
};

struct by_card_grantee; // for protocol (duplicate check) and cascade removal
struct by_card;         // for API - a card's grants, pageable
struct by_grantee;      // for API - "shared with me"

/**
* @ingroup object_index
*/
using content_card_grant_multi_index_type = multi_index_container<
   content_card_grant_object,
   indexed_by<
      ordered_unique< tag<by_id>, member< object, object_id_type, &object::id > >,
      ordered_unique< tag<by_card_grantee>,
         composite_key< content_card_grant_object,
            member< content_card_grant_object, content_card_id_type, &content_card_grant_object::card >,
            member< content_card_grant_object, data_room_member_ref, &content_card_grant_object::grantee >
         >
      >,
      ordered_unique< tag<by_card>,
         composite_key< content_card_grant_object,
            member< content_card_grant_object, content_card_id_type, &content_card_grant_object::card >,
            member< object, object_id_type, &object::id>
         >
      >,
      ordered_unique< tag<by_grantee>,
         composite_key< content_card_grant_object,
            member< content_card_grant_object, data_room_member_ref, &content_card_grant_object::grantee >,
            member< object, object_id_type, &object::id>
         >
      >
   >
>;

/**
* @ingroup object_index
*/
using content_card_grant_index = generic_index<content_card_grant_object,
                                               content_card_grant_multi_index_type>;

/**
 *  @brief One content card embedded into one other data room, by reference.
 *  @ingroup object
 *  @ingroup protocol
 *
 *  The card stays in its home room (which keeps deciding who may edit it); the link
 *  places it on another room's table with the content key re-wrapped to that room's
 *  key. Readers follow the card's identity, so an update in the home room is visible
 *  everywhere at once. `card_epoch` records which content key the wrap corresponds
 *  to - when the card's key rotates, the link stays but goes stale until refreshed.
 */
class content_card_link_object : public abstract_object<content_card_link_object,
                                           protocol_ids, content_card_link_object_type>
{
   public:
      content_card_id_type card;       ///< The linked card
      data_room_id_type    room;       ///< The TARGET room the card is embedded into
      data_room_member_ref linker;     ///< The member who placed the link
      string               link_key;   ///< Card content key wrapped to the target room's key; empty for public content
      uint32_t             link_epoch = 0; ///< Target room key epoch the wrap targets
      uint32_t             card_epoch = 0; ///< Card key_epoch the wrap corresponds to
      time_point_sec       created;    ///< Link time (head block time)
};

struct by_room_card; // for protocol (duplicate check) and API
struct by_link_card; // for cascade removal and "where is this card embedded"

/**
* @ingroup object_index
*/
using content_card_link_multi_index_type = multi_index_container<
   content_card_link_object,
   indexed_by<
      ordered_unique< tag<by_id>, member< object, object_id_type, &object::id > >,
      ordered_unique< tag<by_room_card>,
         composite_key< content_card_link_object,
            member< content_card_link_object, data_room_id_type, &content_card_link_object::room >,
            member< content_card_link_object, content_card_id_type, &content_card_link_object::card >
         >
      >,
      ordered_unique< tag<by_link_card>,
         composite_key< content_card_link_object,
            member< content_card_link_object, content_card_id_type, &content_card_link_object::card >,
            member< object, object_id_type, &object::id>
         >
      >
   >
>;

/**
* @ingroup object_index
*/
using content_card_link_index = generic_index<content_card_link_object,
                                              content_card_link_multi_index_type>;

} } // graphene::chain

MAP_OBJECT_ID_TO_TYPE( graphene::chain::content_card_object )
MAP_OBJECT_ID_TO_TYPE( graphene::chain::content_card_grant_object )
MAP_OBJECT_ID_TO_TYPE( graphene::chain::content_card_link_object )

FC_REFLECT_TYPENAME( graphene::chain::content_card_object )
FC_REFLECT_TYPENAME( graphene::chain::content_card_grant_object )
FC_REFLECT_TYPENAME( graphene::chain::content_card_link_object )

GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::chain::content_card_object )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::chain::content_card_grant_object )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::chain::content_card_link_object )
