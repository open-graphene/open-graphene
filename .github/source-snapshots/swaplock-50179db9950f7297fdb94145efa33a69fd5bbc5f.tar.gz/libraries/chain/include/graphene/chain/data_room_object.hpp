/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once

#include <graphene/chain/types.hpp>
#include <graphene/db/generic_index.hpp>
#include <graphene/protocol/data_room.hpp>

#include <boost/multi_index/composite_key.hpp>

namespace graphene { namespace chain {

/**
 *  @brief A data room is a container for content cards, optionally attached to a tokenized
 *         asset or an account, with per-member permissions and optional encryption.
 *  @ingroup object
 *  @ingroup protocol
 */
class data_room_object : public abstract_object<data_room_object, protocol_ids, data_room_object_type>
{
   public:
      account_id_type   owner;             ///< Owner of the data room
      string            name;              ///< Room name, unique per owner
      string            description;       ///< Free-form description
      data_room_subject subject;           ///< What the room is attached to (nothing / asset / account)
      /// Whether the key-epoch machinery is active. Every member's envelope - the
      /// owner's included - lives on their member record; the room itself holds no key.
      bool              encrypted = false;
      uint32_t          current_epoch = 0; ///< Current key epoch
      time_point_sec    created;           ///< Creation time (head block time)

      /// Key extractors for the by_subject index (a static_variant cannot be indexed directly)
      uint16_t subject_which()const { return uint16_t( subject.which() ); }
      uint64_t subject_instance()const
      {
         if( subject.is_type<asset_id_type>() )
            return subject.get<asset_id_type>().instance.value;
         if( subject.is_type<account_id_type>() )
            return subject.get<account_id_type>().instance.value;
         return 0;
      }
};

struct by_owner;      // for API
struct by_owner_name; // for protocol
struct by_subject;    // for API

/**
* @ingroup object_index
*/
using data_room_multi_index_type = multi_index_container<
   data_room_object,
   indexed_by<
      ordered_unique< tag<by_id>, member< object, object_id_type, &object::id > >,
      ordered_unique< tag<by_owner>,
         composite_key< data_room_object,
            member< data_room_object, account_id_type, &data_room_object::owner >,
            member< object, object_id_type, &object::id>
         >
      >,
      ordered_unique< tag<by_owner_name>,
         composite_key< data_room_object,
            member< data_room_object, account_id_type, &data_room_object::owner >,
            member< data_room_object, string, &data_room_object::name >
         >
      >,
      ordered_unique< tag<by_subject>,
         composite_key< data_room_object,
            const_mem_fun< data_room_object, uint16_t, &data_room_object::subject_which >,
            const_mem_fun< data_room_object, uint64_t, &data_room_object::subject_instance >,
            member< object, object_id_type, &object::id>
         >
      >
   >
>;

/**
* @ingroup object_index
*/
using data_room_index = generic_index<data_room_object, data_room_multi_index_type>;


/**
 *  @brief Membership of an account or a bare public key in a data room, carrying the
 *         member's permissions and the room key encrypted to the member.
 *  @ingroup object
 *  @ingroup protocol
 *
 *  The room owner always has a member record - it carries the owner's encrypted key -
 *  but the owner's permission flags are irrelevant: ownership implies all permissions.
 *  The owner is always an account; see data_room_member_ref for why key members exist.
 */
class data_room_member_object : public abstract_object<data_room_member_object,
                                          protocol_ids, data_room_member_object_type>
{
   public:
      data_room_id_type    room;            ///< The data room
      data_room_member_ref member;          ///< The member: an account or a public key
      string               member_key;      ///< Room key encrypted to the member; empty for public rooms
      uint32_t             permissions = 0; ///< Permission flags, see DATA_ROOM_PERM_*
      time_point_sec       added;           ///< When the member was added (head block time)
};

struct by_room;        // for API and cascade removal
struct by_room_member; // for protocol
struct by_member;      // for API

/**
* @ingroup object_index
*
* @note The member key is a static_variant. Unlike data_room_object::subject it is indexed
*       directly rather than through extractors, because data_room_member_ref has a total
*       order (operator< in graphene::protocol) that std::less picks up via ADL.
*/
using data_room_member_multi_index_type = multi_index_container<
   data_room_member_object,
   indexed_by<
      ordered_unique< tag<by_id>, member< object, object_id_type, &object::id > >,
      ordered_unique< tag<by_room_member>,
         composite_key< data_room_member_object,
            member< data_room_member_object, data_room_id_type, &data_room_member_object::room >,
            member< data_room_member_object, data_room_member_ref, &data_room_member_object::member >
         >
      >,
      ordered_unique< tag<by_room>,
         composite_key< data_room_member_object,
            member< data_room_member_object, data_room_id_type, &data_room_member_object::room >,
            member< object, object_id_type, &object::id>
         >
      >,
      ordered_unique< tag<by_member>,
         composite_key< data_room_member_object,
            member< data_room_member_object, data_room_member_ref, &data_room_member_object::member >,
            member< object, object_id_type, &object::id>
         >
      >
   >
>;

/**
* @ingroup object_index
*/
using data_room_member_index = generic_index<data_room_member_object, data_room_member_multi_index_type>;


/**
 *  @brief The room key of a given epoch encrypted to a given member.
 *  @ingroup object
 *  @ingroup protocol
 *
 *  Envelopes are per member. A REMAINING member's records survive every removal and
 *  rotation, which is what keeps past epochs decryptable for them. A REMOVED member's
 *  own records are deleted with their membership - they serve nobody else, and keeping
 *  them would silently restore history on a future re-add.
 */
class data_room_key_epoch_object : public abstract_object<data_room_key_epoch_object,
                                             protocol_ids, data_room_key_epoch_object_type>
{
   public:
      data_room_id_type    room;      ///< The data room
      uint32_t             epoch = 0; ///< The key epoch
      data_room_member_ref member;    ///< The member: an account or a public key
      string               key;       ///< Room key of this epoch encrypted to the member
};

struct by_room_epoch_member; // for protocol
struct by_room_member_epoch; // for API

/**
* @ingroup object_index
*/
using data_room_key_epoch_multi_index_type = multi_index_container<
   data_room_key_epoch_object,
   indexed_by<
      ordered_unique< tag<by_id>, member< object, object_id_type, &object::id > >,
      ordered_unique< tag<by_room_epoch_member>,
         composite_key< data_room_key_epoch_object,
            member< data_room_key_epoch_object, data_room_id_type, &data_room_key_epoch_object::room >,
            member< data_room_key_epoch_object, uint32_t, &data_room_key_epoch_object::epoch >,
            member< data_room_key_epoch_object, data_room_member_ref, &data_room_key_epoch_object::member >
         >
      >,
      ordered_unique< tag<by_room_member_epoch>,
         composite_key< data_room_key_epoch_object,
            member< data_room_key_epoch_object, data_room_id_type, &data_room_key_epoch_object::room >,
            member< data_room_key_epoch_object, data_room_member_ref, &data_room_key_epoch_object::member >,
            member< data_room_key_epoch_object, uint32_t, &data_room_key_epoch_object::epoch >
         >
      >,
      ordered_unique< tag<by_room>,
         composite_key< data_room_key_epoch_object,
            member< data_room_key_epoch_object, data_room_id_type, &data_room_key_epoch_object::room >,
            member< object, object_id_type, &object::id>
         >
      >
   >
>;

/**
* @ingroup object_index
*/
using data_room_key_epoch_index = generic_index<data_room_key_epoch_object,
                                                data_room_key_epoch_multi_index_type>;

} } // graphene::chain

MAP_OBJECT_ID_TO_TYPE( graphene::chain::data_room_object )
MAP_OBJECT_ID_TO_TYPE( graphene::chain::data_room_member_object )
MAP_OBJECT_ID_TO_TYPE( graphene::chain::data_room_key_epoch_object )

FC_REFLECT_TYPENAME( graphene::chain::data_room_object )
FC_REFLECT_TYPENAME( graphene::chain::data_room_member_object )
FC_REFLECT_TYPENAME( graphene::chain::data_room_key_epoch_object )

GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::chain::data_room_object )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::chain::data_room_member_object )
GRAPHENE_DECLARE_EXTERNAL_SERIALIZATION( graphene::chain::data_room_key_epoch_object )
