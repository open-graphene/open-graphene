/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once
#include <graphene/chain/evaluator.hpp>

#include <graphene/protocol/content_card.hpp>

namespace graphene { namespace chain {

   class database;
   class data_room_object;
   class content_card_object;
   class content_card_grant_object;
   class content_card_link_object;

   namespace detail {
      /// Cascade removal of every grant on @p card - used when a card is removed, when its
      /// content key changes (the old envelopes become undecryptable dead weight), and when
      /// its room is deleted.
      void remove_content_card_grants( database& d, content_card_id_type card );

      /// Cascade removal of every link of @p card - used when the card is removed and when
      /// its home room is deleted. Links deliberately SURVIVE content-key rotation (they
      /// reference identity, not bytes; a stale wrap is refreshed with link_update).
      void remove_content_card_links( database& d, content_card_id_type card );

      /// Cascade removal of every link EMBEDDED INTO @p room - used when the room is deleted.
      void remove_room_content_card_links( database& d, data_room_id_type room );
   } // namespace detail

   class content_card_create_evaluator : public evaluator<content_card_create_evaluator>
   {
      public:
         using operation_type = content_card_create_operation;

         void_result do_evaluate( const content_card_create_operation& op );
         object_id_type do_apply( const content_card_create_operation& op ) const;

         const data_room_object* _room = nullptr;
   };

   class content_card_update_evaluator : public evaluator<content_card_update_evaluator>
   {
      public:
         using operation_type = content_card_update_operation;

         void_result do_evaluate( const content_card_update_operation& op );
         void_result do_apply( const content_card_update_operation& op ) const;

         const data_room_object* _room = nullptr;
         const content_card_object* _card = nullptr;
   };

   class content_card_remove_evaluator : public evaluator<content_card_remove_evaluator>
   {
      public:
         using operation_type = content_card_remove_operation;

         void_result do_evaluate( const content_card_remove_operation& op );
         void_result do_apply( const content_card_remove_operation& op ) const;

         const content_card_object* _card = nullptr;
   };

   class content_card_grant_create_evaluator : public evaluator<content_card_grant_create_evaluator>
   {
      public:
         using operation_type = content_card_grant_create_operation;

         void_result do_evaluate( const content_card_grant_create_operation& op );
         object_id_type do_apply( const content_card_grant_create_operation& op ) const;

         const content_card_object* _card = nullptr;
         const data_room_object* _room = nullptr;
   };

   class content_card_grant_revoke_evaluator : public evaluator<content_card_grant_revoke_evaluator>
   {
      public:
         using operation_type = content_card_grant_revoke_operation;

         void_result do_evaluate( const content_card_grant_revoke_operation& op );
         void_result do_apply( const content_card_grant_revoke_operation& op ) const;

         const content_card_grant_object* _grant = nullptr;
   };

   class content_card_link_create_evaluator : public evaluator<content_card_link_create_evaluator>
   {
      public:
         using operation_type = content_card_link_create_operation;

         void_result do_evaluate( const content_card_link_create_operation& op );
         object_id_type do_apply( const content_card_link_create_operation& op ) const;

         const content_card_object* _card = nullptr;
         const data_room_object* _target = nullptr;
   };

   class content_card_link_update_evaluator : public evaluator<content_card_link_update_evaluator>
   {
      public:
         using operation_type = content_card_link_update_operation;

         void_result do_evaluate( const content_card_link_update_operation& op );
         void_result do_apply( const content_card_link_update_operation& op ) const;

         const content_card_link_object* _link = nullptr;
         const content_card_object* _card = nullptr;
         const data_room_object* _target = nullptr;
   };

   class content_card_link_remove_evaluator : public evaluator<content_card_link_remove_evaluator>
   {
      public:
         using operation_type = content_card_link_remove_operation;

         void_result do_evaluate( const content_card_link_remove_operation& op );
         void_result do_apply( const content_card_link_remove_operation& op ) const;

         const content_card_link_object* _link = nullptr;
   };

} } // graphene::chain
