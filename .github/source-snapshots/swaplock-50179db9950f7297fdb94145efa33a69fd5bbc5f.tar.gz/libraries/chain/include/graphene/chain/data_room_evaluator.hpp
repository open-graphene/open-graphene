/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#pragma once
#include <graphene/chain/evaluator.hpp>

#include <graphene/protocol/data_room.hpp>

namespace graphene { namespace chain {

   class data_room_object;
   class data_room_member_object;

   namespace detail {
      /// Find the member record of @p member in @p room, or nullptr if not a member.
      /// @p member may be an account or a bare public key; account_id_type converts
      /// implicitly, so account-only call sites need no change.
      const data_room_member_object* find_data_room_member( const database& d,
            data_room_id_type room, const data_room_member_ref& member );

      /// Require @p caller to be the room owner (implicit all permissions) or a member
      /// holding @p required_flag; throws otherwise
      void require_data_room_permission( const database& d, const data_room_object& room,
            const data_room_member_ref& caller, uint32_t required_flag, const char* action_desc );
   } // namespace detail

   class data_room_create_evaluator : public evaluator<data_room_create_evaluator>
   {
      public:
         using operation_type = data_room_create_operation;

         void_result do_evaluate( const data_room_create_operation& op ) const;
         object_id_type do_apply( const data_room_create_operation& op ) const;
   };

   class data_room_update_evaluator : public evaluator<data_room_update_evaluator>
   {
      public:
         using operation_type = data_room_update_operation;

         void_result do_evaluate( const data_room_update_operation& op );
         void_result do_apply( const data_room_update_operation& op ) const;

         const data_room_object* _room = nullptr;
   };

   class data_room_delete_evaluator : public evaluator<data_room_delete_evaluator>
   {
      public:
         using operation_type = data_room_delete_operation;

         void_result do_evaluate( const data_room_delete_operation& op );
         void_result do_apply( const data_room_delete_operation& op ) const;

         const data_room_object* _room = nullptr;
   };

   class data_room_member_add_evaluator : public evaluator<data_room_member_add_evaluator>
   {
      public:
         using operation_type = data_room_member_add_operation;

         void_result do_evaluate( const data_room_member_add_operation& op );
         object_id_type do_apply( const data_room_member_add_operation& op ) const;

         const data_room_object* _room = nullptr;
   };

   class data_room_member_update_evaluator : public evaluator<data_room_member_update_evaluator>
   {
      public:
         using operation_type = data_room_member_update_operation;

         void_result do_evaluate( const data_room_member_update_operation& op );
         void_result do_apply( const data_room_member_update_operation& op ) const;

         const data_room_object* _room = nullptr;
         const data_room_member_object* _member = nullptr;
   };

   class data_room_member_remove_evaluator : public evaluator<data_room_member_remove_evaluator>
   {
      public:
         using operation_type = data_room_member_remove_operation;

         void_result do_evaluate( const data_room_member_remove_operation& op );
         void_result do_apply( const data_room_member_remove_operation& op ) const;

         const data_room_object* _room = nullptr;
         const data_room_member_object* _member = nullptr;
   };

   class data_room_rotate_key_evaluator : public evaluator<data_room_rotate_key_evaluator>
   {
      public:
         using operation_type = data_room_rotate_key_operation;

         void_result do_evaluate( const data_room_rotate_key_operation& op );
         void_result do_apply( const data_room_rotate_key_operation& op ) const;

         const data_room_object* _room = nullptr;
   };

} } // graphene::chain
