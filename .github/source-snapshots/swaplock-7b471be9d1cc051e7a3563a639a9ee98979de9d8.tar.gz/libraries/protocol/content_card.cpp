/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <graphene/protocol/content_card.hpp>

#include <fc/io/raw.hpp>

namespace graphene { namespace protocol {

/*
 * A room cannot sign, so it can never be the acting party of a card operation - an
 * authority for it does not exist, and accepting one would make authorship forgeable.
 * Rooms READ through their keyring membership; they do not act. Grants to rooms are
 * rejected too: sharing a card with a whole room is what links are for.
 */
static void reject_room_ref( const data_room_member_ref& ref, const char* role )
{
   FC_ASSERT( !ref.is_type<data_room_id_type>(),
              "A data room cannot be the ${r} of a content card operation: a room cannot "
              "sign, its access is read-only", ("r", string(role)) );
}

void content_card_create_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   reject_room_ref( author, "author" );
   FC_ASSERT( !hash.empty(), "Hash should not be empty" );
   FC_ASSERT( !url.empty(), "URL should not be empty" );
   FC_ASSERT( !storage_data.empty(), "Storage data should not be empty" );
}

share_type content_card_create_operation::calculate_fee( const fee_params_t& schedule )const
{
   share_type core_fee_required = schedule.fee;
   core_fee_required += calculate_data_fee( fc::raw::pack_size(*this), schedule.price_per_kbyte );
   return core_fee_required;
}

void content_card_update_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   reject_room_ref( caller, "caller" );
   if( extensions.value.expected_hash.valid() )
      FC_ASSERT( !extensions.value.expected_hash->empty(), "Expected hash must not be empty" );
   bool updating_something = false;

   if( new_hash.valid() )
   {
      updating_something = true;
      FC_ASSERT( !new_hash->empty(), "Hash should not be empty" );
   }
   if( new_url.valid() )
   {
      updating_something = true;
      FC_ASSERT( !new_url->empty(), "URL should not be empty" );
   }
   if( new_type.valid() )
      updating_something = true;
   if( new_description.valid() )
      updating_something = true;
   if( new_content_key.valid() )
      updating_something = true;
   if( new_storage_data.valid() )
   {
      updating_something = true;
      FC_ASSERT( !new_storage_data->empty(), "Storage data should not be empty" );
   }

   FC_ASSERT( updating_something,
              "Should change something - at least one of the optional data fields should be present" );
}

share_type content_card_update_operation::calculate_fee( const fee_params_t& schedule )const
{
   share_type core_fee_required = schedule.fee;
   core_fee_required += calculate_data_fee( fc::raw::pack_size(*this), schedule.price_per_kbyte );
   return core_fee_required;
}

void content_card_remove_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   if( extensions.value.expected_hash.valid() )
      FC_ASSERT( !extensions.value.expected_hash->empty(), "Expected hash must not be empty" );
   reject_room_ref( caller, "caller" );
}

void content_card_grant_create_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   reject_room_ref( grantee, "grantee" );
   // An empty envelope would record a disclosure that discloses nothing - the grantee
   // could never decrypt. Public rooms need no grants; the evaluator rejects them.
   FC_ASSERT( !key.empty(), "Grant key should not be empty" );
   if( grantee.is_type<account_id_type>() )
      FC_ASSERT( grantee.get<account_id_type>() != granter,
                 "Granting a card to yourself is meaningless - the granter can already read it" );
}

share_type content_card_grant_create_operation::calculate_fee( const fee_params_t& schedule )const
{
   share_type core_fee_required = schedule.fee;
   core_fee_required += calculate_data_fee( fc::raw::pack_size(*this), schedule.price_per_kbyte );
   return core_fee_required;
}

void content_card_grant_revoke_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
}

void content_card_link_create_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   reject_room_ref( caller, "caller" );
   // link_key may legitimately be empty - a public card in a public room - so the
   // encrypted-content rules live in the evaluator, where the card is visible.
}

share_type content_card_link_create_operation::calculate_fee( const fee_params_t& schedule )const
{
   share_type core_fee_required = schedule.fee;
   core_fee_required += calculate_data_fee( fc::raw::pack_size(*this), schedule.price_per_kbyte );
   return core_fee_required;
}

void content_card_link_update_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   reject_room_ref( caller, "caller" );
   FC_ASSERT( !new_link_key.empty(), "A refreshed link must carry a new wrapped key" );
}

share_type content_card_link_update_operation::calculate_fee( const fee_params_t& schedule )const
{
   share_type core_fee_required = schedule.fee;
   core_fee_required += calculate_data_fee( fc::raw::pack_size(*this), schedule.price_per_kbyte );
   return core_fee_required;
}

void content_card_link_remove_operation::validate()const
{
   FC_ASSERT( fee.amount >= 0, "Fee should not be negative" );
   reject_room_ref( caller, "caller" );
}

} } // graphene::protocol

GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_create_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_update_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_remove_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_grant_create_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_grant_revoke_operation::fee_params_t )

GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_create_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_update_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_remove_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_grant_create_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_grant_revoke_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_create_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_update_operation::fee_params_t )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_remove_operation::fee_params_t )

GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_create_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_update_operation )
GRAPHENE_IMPLEMENT_EXTERNAL_SERIALIZATION( graphene::protocol::content_card_link_remove_operation )
