/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <graphene/chain/content_card_evaluator.hpp>

#include <graphene/chain/data_room_evaluator.hpp>
#include <graphene/chain/data_room_object.hpp>
#include <graphene/chain/content_card_object.hpp>
#include <graphene/chain/database.hpp>
#include <graphene/chain/exceptions.hpp>

namespace graphene { namespace chain {

namespace detail {

void remove_content_card_grants( database& d, content_card_id_type card )
{
   const auto& idx = d.get_index_type<content_card_grant_index>().indices().get<by_card_grantee>();
   auto itr = idx.lower_bound( card );
   while( itr != idx.end() && itr->card == card )
   {
      const auto& grant = *itr;
      ++itr;
      d.remove( grant );
   }
}

void remove_content_card_links( database& d, content_card_id_type card )
{
   const auto& idx = d.get_index_type<content_card_link_index>().indices().get<by_link_card>();
   auto itr = idx.lower_bound( card );
   while( itr != idx.end() && itr->card == card )
   {
      const auto& link = *itr;
      ++itr;
      d.remove( link );
   }
}

void remove_room_content_card_links( database& d, data_room_id_type room )
{
   const auto& idx = d.get_index_type<content_card_link_index>().indices().get<by_room_card>();
   auto itr = idx.lower_bound( room );
   while( itr != idx.end() && itr->room == room )
   {
      const auto& link = *itr;
      ++itr;
      d.remove( link );
   }
}

} // namespace detail

namespace {

/// The caller may manage (update / remove) a card if they are its author, the room owner,
/// or a member with DATA_ROOM_PERM_MANAGE_CONTENT
void require_content_card_authority( const database& d, const data_room_object& room,
                                     const content_card_object& card,
                                     const data_room_member_ref& caller )
{
   if( room.write_policy == 0 && caller == card.author )
      return;
   detail::require_data_room_permission( d, room, caller,
                                         DATA_ROOM_PERM_MANAGE_CONTENT, "manage content" );
}

/// Membership without any permission requirement: the owner counts, a member record counts.
bool is_data_room_member( const database& d, const data_room_object& room,
                          const data_room_member_ref& who )
{
   if( who.is_type<account_id_type>() && room.owner == who.get<account_id_type>() )
      return true;
   return detail::find_data_room_member( d, room.get_id(), who ) != nullptr;
}

/// Non-throwing sibling of require_data_room_permission - for authority checks with
/// several independent ways in.
bool has_data_room_permission( const database& d, const data_room_object& room,
                               const data_room_member_ref& who, uint32_t required_flag )
{
   if( who.is_type<account_id_type>() && room.owner == who.get<account_id_type>() )
      return true;
   const auto* member = detail::find_data_room_member( d, room.get_id(), who );
   return member != nullptr && ( member->permissions & required_flag ) != 0;
}

} // anonymous namespace

// ============ content_card_create_evaluator ============

void_result content_card_create_evaluator::do_evaluate( const content_card_create_operation& op )
{ try {
   const database& d = db();

   _room = &op.room(d);
   detail::require_data_room_permission( d, *_room, op.author,
                                         DATA_ROOM_PERM_CREATE_CONTENT, "create content" );

   // No uniqueness check on the hash: it is an integrity anchor, not an identity. The
   // same document filed twice is two cards, each with its own object id.

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

object_id_type content_card_create_evaluator::do_apply( const content_card_create_operation& op ) const
{ try {
   database& d = db();
   const auto now = d.head_block_time();

   const auto& new_card = d.create<content_card_object>( [&op, this, now]( content_card_object& obj )
   {
      obj.author       = op.author;
      obj.room         = op.room;
      obj.hash         = op.hash;
      obj.url          = op.url;
      obj.type         = op.type;
      obj.description  = op.description;
      obj.content_key  = op.content_key;
      obj.storage_data = op.storage_data;
      obj.key_epoch    = _room->current_epoch;
      obj.created      = now;
      obj.updated      = now;
   });

   return new_card.id;
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ content_card_update_evaluator ============

void_result content_card_update_evaluator::do_evaluate( const content_card_update_operation& op )
{ try {
   const database& d = db();

   _card = &op.content_id(d);
   _room = &_card->room(d);

   require_content_card_authority( d, *_room, *_card, op.caller );

   if( _room->write_policy == 1 )
   {
      FC_ASSERT( op.extensions.value.expected_hash.valid(), "Expected hash is required" );
      FC_ASSERT( op.new_hash.valid() && *op.new_hash != _card->hash,
                 "A new revision must change the content hash" );
   }
   if( op.extensions.value.expected_hash.valid() )
      FC_ASSERT( _card->hash == *op.extensions.value.expected_hash,
                 "Content card revision conflict" );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result content_card_update_evaluator::do_apply( const content_card_update_operation& op ) const
{ try {
   database& d = db();
   const auto now = d.head_block_time();

   d.modify( *_card, [&op, this, now]( content_card_object& obj )
   {
      if( op.new_hash.valid() )
         obj.hash = *op.new_hash;
      if( op.new_url.valid() )
         obj.url = *op.new_url;
      if( op.new_type.valid() )
         obj.type = *op.new_type;
      if( op.new_description.valid() )
         obj.description = *op.new_description;
      if( op.new_content_key.valid() )
      {
         obj.content_key = *op.new_content_key;
         obj.key_epoch   = _room->current_epoch;
      }
      if( op.new_storage_data.valid() )
         obj.storage_data = *op.new_storage_data;
      obj.updated = now;
   });

   // A new content key means new content: every existing grant wraps the OLD key and
   // would decrypt nothing. Grants state current intent - dead envelopes are removed,
   // and re-granting the new content is a fresh, explicit act.
   if( op.new_content_key.valid() )
      detail::remove_content_card_grants( d, _card->get_id() );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ content_card_remove_evaluator ============

void_result content_card_remove_evaluator::do_evaluate( const content_card_remove_operation& op )
{ try {
   const database& d = db();

   _card = &op.content_id(d);
   const data_room_object& room = _card->room(d);

   require_content_card_authority( d, room, *_card, op.caller );
   if( room.write_policy == 1 )
      FC_ASSERT( op.extensions.value.expected_hash.valid(), "Expected hash is required" );
   if( op.extensions.value.expected_hash.valid() )
      FC_ASSERT( _card->hash == *op.extensions.value.expected_hash, "Content card revision conflict" );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result content_card_remove_evaluator::do_apply( const content_card_remove_operation& op ) const
{ try {
   database& d = db();

   detail::remove_content_card_grants( d, _card->get_id() );
   detail::remove_content_card_links( d, _card->get_id() );
   d.remove( *_card );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ content_card_grant_create_evaluator ============

void_result content_card_grant_create_evaluator::do_evaluate( const content_card_grant_create_operation& op )
{ try {
   const database& d = db();

   _card = &op.content_id(d);
   _room = &_card->room(d);

   detail::require_data_room_permission( d, *_room, op.granter,
                                         DATA_ROOM_PERM_GRANT_CONTENT, "grant content" );

   // A public room's cards are readable by anyone; a grant would record a disclosure
   // of something that was never withheld.
   FC_ASSERT( _room->encrypted, "Cannot grant content of a public data room" );

   if( op.grantee.is_type<account_id_type>() )
      op.grantee.get<account_id_type>()(d);

   const auto& idx = d.get_index_type<content_card_grant_index>().indices().get<by_card_grantee>();
   auto itr = idx.find( boost::make_tuple( op.content_id, op.grantee ) );
   FC_ASSERT( itr == idx.end(), "This card is already granted to this grantee" );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

object_id_type content_card_grant_create_evaluator::do_apply( const content_card_grant_create_operation& op ) const
{ try {
   database& d = db();
   const auto now = d.head_block_time();

   const auto& grant = d.create<content_card_grant_object>( [&op, now]( content_card_grant_object& obj )
   {
      obj.card       = op.content_id;
      obj.grantee    = op.grantee;
      obj.key        = op.key;
      obj.granted_by = op.granter;
      obj.created    = now;
   });

   return grant.id;
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ content_card_grant_revoke_evaluator ============

void_result content_card_grant_revoke_evaluator::do_evaluate( const content_card_grant_revoke_operation& op )
{ try {
   const database& d = db();

   _grant = &op.grant_id(d);

   // The granter may always retract their own act; beyond that, revocation is gated by
   // the same permission that gates granting.
   if( op.caller != _grant->granted_by )
   {
      const content_card_object& card = _grant->card(d);
      const data_room_object& room = card.room(d);
      detail::require_data_room_permission( d, room, op.caller,
                                            DATA_ROOM_PERM_GRANT_CONTENT, "revoke content grants" );
   }

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result content_card_grant_revoke_evaluator::do_apply( const content_card_grant_revoke_operation& op ) const
{ try {
   database& d = db();

   d.remove( *_grant );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ content_card_link_create_evaluator ============

void_result content_card_link_create_evaluator::do_evaluate( const content_card_link_create_operation& op )
{ try {
   const database& d = db();

   _card = &op.content_id(d);
   const data_room_object& home = _card->room(d);
   _target = &op.room(d);

   FC_ASSERT( _target->get_id() != home.get_id(),
              "A card already lives in its home room - linking it there is meaningless" );

   // Whoever may read the case may put it on another table...
   FC_ASSERT( is_data_room_member( d, home, op.caller ),
              "Caller is not a member of the card's home room" );
   // ...but only where they are allowed to create content.
   detail::require_data_room_permission( d, *_target, op.caller,
                                         DATA_ROOM_PERM_CREATE_CONTENT, "link content" );

   if( !_card->content_key.empty() )
   {
      // An encrypted card in a public room would be unreadable forever - there is no
      // room key to wrap its content key to.
      FC_ASSERT( _target->encrypted,
                 "Cannot link an encrypted card into a public data room" );
      FC_ASSERT( !op.link_key.empty(),
                 "Linking an encrypted card requires its content key wrapped to the target room" );
   }
   else
   {
      FC_ASSERT( op.link_key.empty(),
                 "A public card carries no content key - the link must not invent one" );
   }

   const auto& idx = d.get_index_type<content_card_link_index>().indices().get<by_room_card>();
   auto itr = idx.find( boost::make_tuple( op.room, op.content_id ) );
   FC_ASSERT( itr == idx.end(), "This card is already linked into this room" );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

object_id_type content_card_link_create_evaluator::do_apply( const content_card_link_create_operation& op ) const
{ try {
   database& d = db();
   const auto now = d.head_block_time();

   const auto& link = d.create<content_card_link_object>( [&op, this, now]( content_card_link_object& obj )
   {
      obj.card       = op.content_id;
      obj.room       = op.room;
      obj.linker     = op.caller;
      obj.link_key   = op.link_key;
      obj.link_epoch = _target->current_epoch;
      obj.card_epoch = _card->key_epoch;
      obj.created    = now;
   });

   return link.id;
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ content_card_link_update_evaluator ============

void_result content_card_link_update_evaluator::do_evaluate( const content_card_link_update_operation& op )
{ try {
   const database& d = db();

   _link = &op.link_id(d);
   _card = &_link->card(d);
   _target = &_link->room(d);
   const data_room_object& home = _card->room(d);

   FC_ASSERT( op.caller == _link->linker || is_data_room_member( d, home, op.caller ),
              "Only the linker or a member of the card's home room may refresh a link" );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result content_card_link_update_evaluator::do_apply( const content_card_link_update_operation& op ) const
{ try {
   database& d = db();

   d.modify( *_link, [&op, this]( content_card_link_object& obj )
   {
      obj.link_key   = op.new_link_key;
      obj.link_epoch = _target->current_epoch;
      obj.card_epoch = _card->key_epoch;
   });

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ content_card_link_remove_evaluator ============

void_result content_card_link_remove_evaluator::do_evaluate( const content_card_link_remove_operation& op )
{ try {
   const database& d = db();

   _link = &op.link_id(d);
   const content_card_object& card = _link->card(d);
   const data_room_object& home = card.room(d);
   const data_room_object& target = _link->room(d);

   // Three independent ways in: the linker retracts their own act, the home room
   // manages its card's reach, the target room clears its own table.
   const bool allowed = op.caller == _link->linker
      || has_data_room_permission( d, home, op.caller, DATA_ROOM_PERM_MANAGE_CONTENT )
      || has_data_room_permission( d, target, op.caller, DATA_ROOM_PERM_MANAGE_CONTENT );
   FC_ASSERT( allowed,
              "Only the linker, the card's home room (manage content), or the target room "
              "(manage content) may remove a link" );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result content_card_link_remove_evaluator::do_apply( const content_card_link_remove_operation& op ) const
{ try {
   database& d = db();

   d.remove( *_link );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

} } // graphene::chain
