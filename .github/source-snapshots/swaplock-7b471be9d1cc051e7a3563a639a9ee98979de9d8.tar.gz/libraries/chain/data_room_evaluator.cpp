/*
 * Copyright (c) 2026 SwapLock, and contributors.
 *
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
#include <graphene/chain/data_room_evaluator.hpp>

#include <graphene/chain/data_room_object.hpp>
#include <graphene/chain/content_card_evaluator.hpp> // detail::remove_content_card_grants
#include <graphene/chain/content_card_object.hpp>
#include <graphene/chain/account_object.hpp>
#include <graphene/chain/asset_object.hpp>
#include <graphene/chain/database.hpp>
#include <graphene/chain/exceptions.hpp>
#include <fc/io/raw.hpp>

namespace graphene { namespace chain {

namespace detail {

data_room_access_state read_data_room_access_state( const database& d, const data_room_object& room )
{
   data_room_access_state state;
   state.room = room.get_id();
   state.owner = room.owner;
   state.encrypted = room.encrypted;
   state.current_epoch = room.current_epoch;
   const auto& idx = d.get_index_type<data_room_member_index>().indices().get<by_room>();
   for( auto itr = idx.lower_bound( room.get_id() );
        itr != idx.end() && itr->room == room.get_id(); ++itr )
      state.members.push_back( { itr->id.instance(), itr->member,
                                 itr->permissions, itr->member_key } );
   return state;
}

digest_type data_room_access_digest( const database& d, const data_room_object& room )
{
   const auto state = read_data_room_access_state( d, room );
   fc::sha256::encoder encoder;
   fc::raw::pack( encoder, state );
   return encoder.result();
}

static void require_access_state( const database& d, const data_room_object& room,
                                  const data_room_access_extensions& extensions )
{
   if( extensions.expected_access_state.valid() )
      FC_ASSERT( *extensions.expected_access_state == data_room_access_digest( d, room ).str(),
                 "Data room access state changed" );
}

const data_room_member_object* find_data_room_member( const database& d,
      data_room_id_type room, const data_room_member_ref& member )
{
   const auto& idx = d.get_index_type<data_room_member_index>().indices().get<by_room_member>();
   auto itr = idx.find( boost::make_tuple( room, member ) );
   if( itr != idx.end() )
      return &(*itr);
   return nullptr;
}

void require_data_room_permission( const database& d, const data_room_object& room,
      const data_room_member_ref& caller, uint32_t required_flag, const char* action_desc )
{
   if( caller.is_type<account_id_type>() && room.owner == caller.get<account_id_type>() )
      return; // The owner implicitly has all permissions

   const auto* member = find_data_room_member( d, room.get_id(), caller );
   FC_ASSERT( member != nullptr, "Caller is not a member of this data room" );
   FC_ASSERT( ( member->permissions & required_flag ) != 0,
              "Caller does not have permission to ${action}",
              ("action", action_desc) );
}

/// Whether the room's key-epoch machinery is active
static bool is_encrypted( const data_room_object& room )
{
   return room.encrypted;
}

/// Validate that @p authorizer may attach @p subject: an asset requires its issuer,
/// an account requires the account itself
static void validate_data_room_subject( const database& d, const data_room_subject& subject,
                                        account_id_type authorizer )
{
   if( subject.is_type<asset_id_type>() )
   {
      const asset_object& subject_asset = subject.get<asset_id_type>()(d);
      FC_ASSERT( subject_asset.issuer == authorizer,
                 "Only the asset issuer can attach a data room to asset ${a}",
                 ("a", subject_asset.symbol) );
   }
   else if( subject.is_type<account_id_type>() )
   {
      const account_object& subject_account = subject.get<account_id_type>()(d);
      FC_ASSERT( subject_account.get_id() == authorizer,
                 "Only the account itself can attach a data room to account ${a}",
                 ("a", subject_account.name) );
   }
}

} // namespace detail

// ============ data_room_create_evaluator ============

void_result data_room_create_evaluator::do_evaluate( const data_room_create_operation& op ) const
{ try {
   const database& d = db();

   const auto& idx = d.get_index_type<data_room_index>().indices().get<by_owner_name>();
   auto itr = idx.find( boost::make_tuple( op.owner, op.name ) );
   FC_ASSERT( itr == idx.end(), "A data room with this name already exists for this owner" );

   detail::validate_data_room_subject( d, op.subject, op.owner );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

object_id_type data_room_create_evaluator::do_apply( const data_room_create_operation& op ) const
{ try {
   database& d = db();
   const auto now = d.head_block_time();

   const auto& new_room = d.create<data_room_object>( [&op, now]( data_room_object& obj )
   {
      obj.owner         = op.owner;
      obj.name          = op.name;
      obj.description   = op.description;
      obj.subject       = op.subject;
      obj.encrypted     = op.room_key.valid();
      obj.write_policy = op.extensions.value.write_policy.valid() ? *op.extensions.value.write_policy : 0;
      obj.current_epoch = 0;
      obj.created       = now;
   });

   // The owner is always a member - the member record carries the owner's encrypted key.
   // The owner's permission flags are irrelevant: ownership implies all permissions.
   d.create<data_room_member_object>( [&op, &new_room, now]( data_room_member_object& obj )
   {
      obj.room       = new_room.get_id();
      obj.member     = op.owner;
      obj.member_key = op.room_key.valid() ? *op.room_key : "";
      obj.added      = now;
   });

   if( op.room_key.valid() )
   {
      d.create<data_room_key_epoch_object>( [&op, &new_room]( data_room_key_epoch_object& obj )
      {
         obj.room    = new_room.get_id();
         obj.epoch   = 0;
         obj.member  = op.owner;
         obj.key     = *op.room_key;
      });
   }

   return new_room.id;
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ data_room_update_evaluator ============

void_result data_room_update_evaluator::do_evaluate( const data_room_update_operation& op )
{ try {
   const database& d = db();

   _room = &op.room(d);

   if( op.new_subject.valid() || op.new_owner.valid() )
      FC_ASSERT( op.caller == _room->owner,
                 "Only the owner can change the subject or transfer ownership of a data room" );
   else
      detail::require_data_room_permission( d, *_room, op.caller,
                                            DATA_ROOM_PERM_UPDATE_ROOM, "update room" );

   if( op.new_subject.valid() )
      detail::validate_data_room_subject( d, *op.new_subject, op.caller );

   account_id_type future_owner = op.new_owner.valid() ? *op.new_owner : _room->owner;

   if( op.new_owner.valid() )
   {
      FC_ASSERT( *op.new_owner != _room->owner, "New owner should be different from the current owner" );
      (*op.new_owner)(d); // Make sure the account exists
      if( detail::is_encrypted( *_room ) )
         FC_ASSERT( detail::find_data_room_member( d, _room->get_id(), *op.new_owner ) != nullptr,
                    "An encrypted data room can only be transferred to an existing member "
                    "- the new owner needs the room keys" );
   }

   const string& future_name = op.new_name.valid() ? *op.new_name : _room->name;
   if( future_owner != _room->owner || future_name != _room->name )
   {
      const auto& idx = d.get_index_type<data_room_index>().indices().get<by_owner_name>();
      auto itr = idx.find( boost::make_tuple( future_owner, future_name ) );
      FC_ASSERT( itr == idx.end(), "A data room with this name already exists for this owner" );
   }

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result data_room_update_evaluator::do_apply( const data_room_update_operation& op ) const
{ try {
   database& d = db();

   d.modify( *_room, [&op]( data_room_object& obj )
   {
      if( op.new_name.valid() )
         obj.name = *op.new_name;
      if( op.new_description.valid() )
         obj.description = *op.new_description;
      if( op.new_subject.valid() )
         obj.subject = *op.new_subject;
      if( op.new_owner.valid() )
         obj.owner = *op.new_owner;
   });

   // For a public room the new owner may not have a member record yet; create it so the
   // owner invariant (owner is always a member) holds. Encrypted rooms require the new
   // owner to be a member already - checked in do_evaluate.
   if( op.new_owner.valid()
       && detail::find_data_room_member( d, _room->get_id(), *op.new_owner ) == nullptr )
   {
      const auto now = d.head_block_time();
      d.create<data_room_member_object>( [&op, this, now]( data_room_member_object& obj )
      {
         obj.room   = _room->get_id();
         obj.member = *op.new_owner;
         obj.added  = now;
      });
   }

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ data_room_delete_evaluator ============

void_result data_room_delete_evaluator::do_evaluate( const data_room_delete_operation& op )
{ try {
   const database& d = db();

   _room = &op.room(d);
   FC_ASSERT( _room->owner == op.caller, "Only the owner can delete a data room" );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result data_room_delete_evaluator::do_apply( const data_room_delete_operation& op ) const
{ try {
   database& d = db();
   const auto room_id = _room->get_id();

   const auto& card_idx = d.get_index_type<content_card_index>().indices().get<by_room>();
   auto card_itr = card_idx.lower_bound( room_id );
   while( card_itr != card_idx.end() && card_itr->room == room_id )
   {
      const auto& card = *card_itr;
      ++card_itr;
      detail::remove_content_card_grants( d, card.get_id() );
      // Links of a card whose home room dies point at nothing - they go with it.
      detail::remove_content_card_links( d, card.get_id() );
      d.remove( card );
   }

   // The other side of the mirror: links EMBEDDED INTO this room from elsewhere.
   detail::remove_room_content_card_links( d, room_id );

   const auto& epoch_idx = d.get_index_type<data_room_key_epoch_index>().indices().get<by_room>();
   auto epoch_itr = epoch_idx.lower_bound( room_id );
   while( epoch_itr != epoch_idx.end() && epoch_itr->room == room_id )
   {
      const auto& epoch_record = *epoch_itr;
      ++epoch_itr;
      d.remove( epoch_record );
   }

   const auto& member_idx = d.get_index_type<data_room_member_index>().indices().get<by_room>();
   auto member_itr = member_idx.lower_bound( room_id );
   while( member_itr != member_idx.end() && member_itr->room == room_id )
   {
      const auto& member = *member_itr;
      ++member_itr;
      d.remove( member );
   }

   /*
    * OUTGOING keyring edges: this room may itself be a member of other rooms. A dead
    * grantee opens nothing, and a dangling membership would silently resurrect access
    * if the room id were ever reused - remove the memberships and their epoch envelopes.
    */
   const data_room_member_ref self_ref{ room_id };
   const auto& by_member_idx = d.get_index_type<data_room_member_index>().indices().get<by_member>();
   auto out_itr = by_member_idx.lower_bound( self_ref );
   while( out_itr != by_member_idx.end() && out_itr->member == self_ref )
   {
      const auto& outgoing = *out_itr;
      ++out_itr;

      const auto& out_epoch_idx = d.get_index_type<data_room_key_epoch_index>().indices()
                                   .get<by_room_member_epoch>();
      auto out_epoch_itr = out_epoch_idx.lower_bound( boost::make_tuple( outgoing.room, self_ref ) );
      while( out_epoch_itr != out_epoch_idx.end()
             && out_epoch_itr->room == outgoing.room && out_epoch_itr->member == self_ref )
      {
         const auto& epoch_record = *out_epoch_itr;
         ++out_epoch_itr;
         d.remove( epoch_record );
      }

      d.remove( outgoing );
   }

   d.remove( *_room );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ data_room_member_add_evaluator ============

void_result data_room_member_add_evaluator::do_evaluate( const data_room_member_add_operation& op )
{ try {
   const database& d = db();

   _room = &op.room(d);
   detail::require_data_room_permission( d, *_room, op.caller,
                                         DATA_ROOM_PERM_ADD_MEMBERS, "add members" );
   detail::require_access_state( d, *_room, op.extensions.value );

   // An account member must exist; a key member needs no prior existence on chain - the
   // chain never resolves it to an object and performs no cryptography on it.
   if( op.member.is_type<account_id_type>() )
      op.member.get<account_id_type>()(d);

   // A room member must exist too, and a room granting access to itself is meaningless.
   if( op.member.is_type<data_room_id_type>() )
   {
      FC_ASSERT( op.member.get<data_room_id_type>() != op.room,
                 "A data room cannot be a member of itself" );
      op.member.get<data_room_id_type>()(d);
   }

   FC_ASSERT( detail::find_data_room_member( d, _room->get_id(), op.member ) == nullptr,
              "This member is already a member of this data room" );

   if( detail::is_encrypted( *_room ) )
      FC_ASSERT( !op.member_key.empty(),
                 "Member key should not be empty when adding a member to an encrypted data room" );

   for( const auto& epoch_key : op.epoch_keys )
      FC_ASSERT( epoch_key.first < _room->current_epoch,
                 "Epoch key ${e} must reference a historical epoch (< current ${c})",
                 ("e", epoch_key.first)("c", _room->current_epoch) );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

object_id_type data_room_member_add_evaluator::do_apply( const data_room_member_add_operation& op ) const
{ try {
   database& d = db();
   const auto now = d.head_block_time();

   const auto& new_member = d.create<data_room_member_object>( [&op, now]( data_room_member_object& obj )
   {
      obj.room        = op.room;
      obj.member      = op.member;
      obj.member_key  = op.member_key;
      obj.permissions = op.permissions;
      obj.added       = now;
   });

   const auto& epoch_idx = d.get_index_type<data_room_key_epoch_index>().indices()
                            .get<by_room_epoch_member>();

   auto upsert_epoch_key = [&d, &epoch_idx, &op]( uint32_t epoch, const string& key )
   {
      auto itr = epoch_idx.find( boost::make_tuple( op.room, epoch, op.member ) );
      if( itr == epoch_idx.end() )
      {
         d.create<data_room_key_epoch_object>( [&op, epoch, &key]( data_room_key_epoch_object& obj )
         {
            obj.room   = op.room;
            obj.epoch  = epoch;
            obj.member = op.member;
            obj.key    = key;
         });
      }
      else
      {
         d.modify( *itr, [&key]( data_room_key_epoch_object& obj ) {
            obj.key = key;
         });
      }
   };

   if( detail::is_encrypted( *_room ) )
      upsert_epoch_key( _room->current_epoch, op.member_key );

   for( const auto& epoch_key : op.epoch_keys )
      upsert_epoch_key( epoch_key.first, epoch_key.second );

   return new_member.id;
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ data_room_member_update_evaluator ============

void_result data_room_member_update_evaluator::do_evaluate( const data_room_member_update_operation& op )
{ try {
   const database& d = db();

   _room = &op.room(d);
   detail::require_data_room_permission( d, *_room, op.caller,
                                         DATA_ROOM_PERM_MANAGE_PERMISSIONS, "manage permissions" );
   detail::require_access_state( d, *_room, op.extensions.value );

   _member = detail::find_data_room_member( d, _room->get_id(), op.member );
   FC_ASSERT( _member != nullptr, "This member is not a member of this data room" );
   FC_ASSERT( !( _member->member == data_room_member_ref( _room->owner ) ),
              "Cannot modify the owner's member record" );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result data_room_member_update_evaluator::do_apply( const data_room_member_update_operation& op ) const
{ try {
   database& d = db();

   d.modify( *_member, [&op]( data_room_member_object& obj ) {
      obj.permissions = op.permissions;
   });

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ data_room_member_remove_evaluator ============

void_result data_room_member_remove_evaluator::do_evaluate( const data_room_member_remove_operation& op )
{ try {
   const database& d = db();

   _room = &op.room(d);
   detail::require_data_room_permission( d, *_room, op.caller,
                                         DATA_ROOM_PERM_REMOVE_MEMBERS, "remove members" );
   detail::require_access_state( d, *_room, op.extensions.value );

   _member = detail::find_data_room_member( d, _room->get_id(), op.member );
   FC_ASSERT( _member != nullptr, "This member is not a member of this data room" );
   FC_ASSERT( !( _member->member == data_room_member_ref( _room->owner ) ),
              "Cannot remove the owner from the data room" );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result data_room_member_remove_evaluator::do_apply( const data_room_member_remove_operation& op ) const
{ try {
   database& d = db();

   // The member's own key-epoch envelopes go with them. They are useless to anyone
   // else - each envelope decrypts only for its member - and retaining them would
   // silently restore this member's history on a future re-add, bypassing the choice
   // data_room_member_add_operation::epoch_keys exists to make explicit. Remaining
   // members' records are untouched; that is what keeps past epochs readable for them.
   const auto room_id = _member->room;
   const auto member_ref = _member->member;
   const auto& epoch_idx = d.get_index_type<data_room_key_epoch_index>().indices()
                            .get<by_room_member_epoch>();
   auto itr = epoch_idx.lower_bound( boost::make_tuple( room_id, member_ref ) );
   while( itr != epoch_idx.end() && itr->room == room_id && itr->member == member_ref )
   {
      const auto& record = *itr;
      ++itr;
      d.remove( record );
   }

   d.remove( *_member );

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

// ============ data_room_rotate_key_evaluator ============

void_result data_room_rotate_key_evaluator::do_evaluate( const data_room_rotate_key_operation& op )
{ try {
   const database& d = db();

   _room = &op.room(d);
   detail::require_data_room_permission( d, *_room, op.caller,
                                         DATA_ROOM_PERM_ROTATE_KEYS, "rotate keys" );
   detail::require_access_state( d, *_room, op.extensions.value );

   flat_set<data_room_member_ref> current_members;
   const auto& member_idx = d.get_index_type<data_room_member_index>().indices().get<by_room>();
   auto itr = member_idx.lower_bound( _room->get_id() );
   while( itr != member_idx.end() && itr->room == _room->get_id() )
   {
      current_members.insert( itr->member );
      ++itr;
   }

   /*
    * Full coverage is demanded for account and key members: their envelopes are wrapped
    * to PUBLIC keys, so the rotator can always produce them. A ROOM member's envelope
    * wraps the grantee room's SYMMETRIC key, which the rotator may not hold - such a
    * member may be omitted and its keyring goes honestly STALE at the old epoch, until
    * someone holding both keys re-grants. Rotation staying the revocation lever is the
    * point, not a gap.
    */
   for( const auto& member : current_members )
      FC_ASSERT( op.member_keys.count( member ) > 0 || member.is_type<data_room_id_type>(),
                 "Missing key for member ${m}", ("m", member) );

   for( const auto& member_key : op.member_keys )
      FC_ASSERT( current_members.count( member_key.first ) > 0,
                 "Key provided for non-member ${m}", ("m", member_key.first) );

   // The owner has a member record, so the full-coverage assert above already
   // guarantees their envelope is present - no separate owner field to reconcile.

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

void_result data_room_rotate_key_evaluator::do_apply( const data_room_rotate_key_operation& op ) const
{ try {
   database& d = db();

   // Also bootstraps encryption on a previously public room
   const uint32_t new_epoch = _room->current_epoch + 1;
   d.modify( *_room, [new_epoch]( data_room_object& obj )
   {
      obj.current_epoch = new_epoch;
      obj.encrypted     = true;
   });

   const auto& member_idx = d.get_index_type<data_room_member_index>().indices().get<by_room>();
   auto itr = member_idx.lower_bound( _room->get_id() );
   while( itr != member_idx.end() && itr->room == _room->get_id() )
   {
      const auto& member = *itr;
      ++itr;

      auto member_key = op.member_keys.find( member.member );
      // do_evaluate guarantees full coverage; be defensive anyway
      if( member_key == op.member_keys.end() )
         continue;

      d.modify( member, [&member_key]( data_room_member_object& obj ) {
         obj.member_key = member_key->second;
      });

      d.create<data_room_key_epoch_object>(
            [&op, &member_key, new_epoch]( data_room_key_epoch_object& obj )
      {
         obj.room   = op.room;
         obj.epoch  = new_epoch;
         obj.member = member_key->first;
         obj.key    = member_key->second;
      });
   }

   return void_result();
} FC_CAPTURE_AND_RETHROW( (op) ) }

} } // graphene::chain
